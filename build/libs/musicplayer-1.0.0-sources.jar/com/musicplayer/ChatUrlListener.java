package com.musicplayer;

import com.musicplayer.audio.YouTubeDownloader;
import com.musicplayer.playback.PlayerSession;
import com.musicplayer.playback.PlaybackManager;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.class_124;
import net.minecraft.class_2561;

public class ChatUrlListener {

    public static void register() {
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
            if (manager == null) {
                return true;
            }
            PlayerSession session = manager.getSession(sender);

            if (session.isWaitingForUrl()) {
                session.setWaitingForUrl(false);
                String text = message.method_46291().getString();

                if (YouTubeDownloader.isValidYouTubeUrl(text)) {
                    manager.playUrl(sender, text, true);
                } else {
                    sender.method_7353(
                            class_2561.method_43470("That doesn't look like a valid YouTube URL. Try again with /music")
                                    .method_27692(class_124.field_1061),
                            false
                    );
                }

                // Cancel the chat message so it doesn't broadcast
                return false;
            }

            if (session.isWaitingForSearchQuery()) {
                session.setWaitingForSearchQuery(false);
                String text = message.method_46291().getString().trim();

                if (!text.isEmpty()) {
                    manager.searchTracks(sender, text);
                } else {
                    sender.method_7353(
                            class_2561.method_43470("Search query cannot be empty. Try again with /music")
                                    .method_27692(class_124.field_1061),
                            false
                    );
                }

                return false;
            }

            return true;
        });
    }
}
