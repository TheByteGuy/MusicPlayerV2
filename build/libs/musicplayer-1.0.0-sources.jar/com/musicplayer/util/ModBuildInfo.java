package com.musicplayer.util;

import com.musicplayer.MusicPlayerMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Comparator;
import java.util.HexFormat;
import java.util.Optional;
import java.util.stream.Stream;

public final class ModBuildInfo {
    private static final int SHORT_HASH_LENGTH = 12;
    private static final BuildInfo CURRENT = loadCurrent();

    private ModBuildInfo() {}

    public static BuildInfo current() {
        return CURRENT;
    }

    public record BuildInfo(String version, String hash, String sourceDescription) {
        public BuildInfo {
            version = normalize(version);
            hash = normalize(hash);
            sourceDescription = normalize(sourceDescription);
        }

        public boolean hasHash() {
            return !hash.isBlank();
        }

        public String shortHash() {
            if (hash.isBlank()) {
                return "unknown";
            }
            return hash.substring(0, Math.min(hash.length(), SHORT_HASH_LENGTH));
        }

        public String describe() {
            if (!version.isBlank() && hasHash()) {
                return version + " (" + shortHash() + ")";
            }
            if (!version.isBlank()) {
                return version;
            }
            if (hasHash()) {
                return shortHash();
            }
            return "unknown";
        }
    }

    private static BuildInfo loadCurrent() {
        String version = FabricLoader.getInstance()
                .getModContainer(MusicPlayerMod.MOD_ID)
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("unknown");

        try {
            Optional<Path> sourcePath = resolveCodeSource();
            if (sourcePath.isEmpty()) {
                return new BuildInfo(version, "", "unknown");
            }

            Path path = sourcePath.get().toAbsolutePath().normalize();
            String hash = Files.isDirectory(path) ? hashDirectory(path) : hashFile(path);
            return new BuildInfo(version, hash, path.toString());
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("Failed to compute mod build hash", e);
            return new BuildInfo(version, "", "unknown");
        }
    }

    private static Optional<Path> resolveCodeSource() {
        try {
            if (MusicPlayerMod.class.getProtectionDomain() == null
                    || MusicPlayerMod.class.getProtectionDomain().getCodeSource() == null
                    || MusicPlayerMod.class.getProtectionDomain().getCodeSource().getLocation() == null) {
                return Optional.empty();
            }

            URI location = MusicPlayerMod.class.getProtectionDomain().getCodeSource().getLocation().toURI();
            return Optional.of(Path.of(location));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    private static String hashFile(Path path) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(path)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) >= 0) {
                digest.update(buffer, 0, read);
            }
        }
        return HexFormat.of().formatHex(digest.digest()).toUpperCase();
    }

    private static String hashDirectory(Path path) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (Stream<Path> stream = Files.walk(path)) {
            stream.filter(Files::isRegularFile)
                    .sorted(Comparator.comparing(file -> path.relativize(file).toString()))
                    .forEach(file -> updateDirectoryDigest(digest, path, file));
        }
        return HexFormat.of().formatHex(digest.digest()).toUpperCase();
    }

    private static void updateDirectoryDigest(MessageDigest digest, Path root, Path file) {
        try {
            digest.update(root.relativize(file).toString().replace('\\', '/').getBytes(java.nio.charset.StandardCharsets.UTF_8));
            try (InputStream in = Files.newInputStream(file)) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) >= 0) {
                    digest.update(buffer, 0, read);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to hash " + file, e);
        }
    }

    private static String normalize(String value) {
        return value != null ? value : "";
    }
}
