package com.musicplayer.util;

public final class NoteUtils {

    // Minecraft noteblock has 25 pitches: F#3 (index 0) to F#5 (index 24)
    // F#3 = MIDI note 54, so index i corresponds to MIDI note 54 + i
    // Frequency of MIDI note n = 440 * 2^((n - 69) / 12)

    public static final int NUM_PITCHES = 25;
    public static final int BASE_MIDI_NOTE = 54; // F#3
    public static final double[] NOTE_FREQUENCIES = new double[NUM_PITCHES];

    static {
        for (int i = 0; i < NUM_PITCHES; i++) {
            int midiNote = BASE_MIDI_NOTE + i;
            NOTE_FREQUENCIES[i] = 440.0 * Math.pow(2.0, (midiNote - 69) / 12.0);
        }
    }

    private NoteUtils() {}

    /**
     * Convert a frequency in Hz to the nearest noteblock pitch index (0-24).
     * Returns -1 if the frequency is outside the noteblock range.
     */
    public static int frequencyToPitch(double frequencyHz) {
        if (frequencyHz <= 0) return -1;

        // Find closest note by comparing to each note frequency
        double minDist = Double.MAX_VALUE;
        int bestPitch = -1;

        for (int i = 0; i < NUM_PITCHES; i++) {
            // Use log-scale distance for better musical matching
            double dist = Math.abs(Math.log(frequencyHz) - Math.log(NOTE_FREQUENCIES[i]));
            if (dist < minDist) {
                minDist = dist;
                bestPitch = i;
            }
        }

        // Reject if more than 1 semitone away from nearest note
        double semitoneDist = 12.0 * Math.abs(Math.log(frequencyHz / NOTE_FREQUENCIES[bestPitch]) / Math.log(2));
        if (semitoneDist > 1.0) return -1;

        return bestPitch;
    }

    /**
     * Convert a noteblock pitch index (0-24) to the Minecraft pitch float parameter.
     * Minecraft uses: pitch = 2^((noteBlockPitch - 12) / 12)
     */
    public static float pitchToMinecraftFloat(int pitchIndex) {
        return (float) Math.pow(2.0, (pitchIndex - 12) / 12.0);
    }

    /**
     * Get the frequency range for noteblock notes.
     */
    public static double getMinFrequency() {
        return NOTE_FREQUENCIES[0] * 0.95; // slightly below F#3
    }

    public static double getMaxFrequency() {
        return NOTE_FREQUENCIES[NUM_PITCHES - 1] * 1.05; // slightly above F#5
    }
}
