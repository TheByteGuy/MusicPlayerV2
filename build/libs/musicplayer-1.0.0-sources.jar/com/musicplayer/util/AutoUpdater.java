package com.musicplayer.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.musicplayer.MusicPlayerMod;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.jar.JarFile;

public class AutoUpdater {

    private static final String GITHUB_COMMITS_API =
            "https://api.github.com/repos/TheByteGuy/MusicPlayerV2/commits?path=build/libs/musicplayer-1.0.0.jar&per_page=1";
    private static final String JAR_DOWNLOAD_URL =
            "https://github.com/TheByteGuy/MusicPlayerV2/raw/main/build/libs/musicplayer-1.0.0.jar";
    private static final long CHECK_INTERVAL_SECONDS = 6 * 60 * 60;
    private static final long INITIAL_DELAY_SECONDS = 30;

    private final Path updateDir;
    private final Path lastCommitFile;
    private final Path stagedJar;
    private ScheduledExecutorService scheduler;

    public AutoUpdater(Path configDir) {
        this.updateDir = configDir.resolve("update");
        this.lastCommitFile = updateDir.resolve("last-commit.txt");
        this.stagedJar = updateDir.resolve("musicplayer-update.jar");
        try {
            Files.createDirectories(updateDir);
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.error("[AutoUpdater] Failed to create update directory", e);
        }
    }

    public void start() {
        applyPendingUpdate();

        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "MusicPlayer-AutoUpdater");
            t.setDaemon(true);
            return t;
        });
        scheduler.scheduleAtFixedRate(this::checkForUpdate, INITIAL_DELAY_SECONDS, CHECK_INTERVAL_SECONDS, TimeUnit.SECONDS);
        MusicPlayerMod.LOGGER.info("[AutoUpdater] Started - will check for updates every {} hours", CHECK_INTERVAL_SECONDS / 3600);
    }

    public void shutdown() {
        if (scheduler != null) {
            scheduler.shutdownNow();
            scheduler = null;
        }
    }

    private void checkForUpdate() {
        try {
            MusicPlayerMod.LOGGER.info("[AutoUpdater] Checking for updates...");

            HttpClient client = HttpClient.newBuilder()
                    .followRedirects(HttpClient.Redirect.ALWAYS)
                    .connectTimeout(Duration.ofSeconds(15))
                    .build();

            // Query GitHub API for latest commit that touched the JAR
            HttpRequest apiRequest = HttpRequest.newBuilder()
                    .uri(URI.create(GITHUB_COMMITS_API))
                    .header("Accept", "application/vnd.github.v3+json")
                    .header("User-Agent", "MusicPlayerMod-AutoUpdater")
                    .timeout(Duration.ofSeconds(15))
                    .GET()
                    .build();

            HttpResponse<String> apiResponse = client.send(apiRequest, HttpResponse.BodyHandlers.ofString());
            if (apiResponse.statusCode() != 200) {
                MusicPlayerMod.LOGGER.warn("[AutoUpdater] GitHub API returned status {}", apiResponse.statusCode());
                return;
            }

            String latestSha = parseCommitSha(apiResponse.body());
            if (latestSha == null || latestSha.isBlank()) {
                MusicPlayerMod.LOGGER.warn("[AutoUpdater] Could not parse commit SHA from GitHub response");
                return;
            }

            // Compare with the SHA we stored last time
            String storedSha = readStoredSha();
            if (latestSha.equals(storedSha)) {
                MusicPlayerMod.LOGGER.info("[AutoUpdater] Already up to date (commit {})", shortSha(latestSha));
                return;
            }

            // First run — record current SHA so we have a baseline
            if (storedSha == null) {
                MusicPlayerMod.LOGGER.info("[AutoUpdater] First run — recording baseline commit {}", shortSha(latestSha));
                saveSha(latestSha);
                return;
            }

            MusicPlayerMod.LOGGER.info("[AutoUpdater] Update available! {} -> {}", shortSha(storedSha), shortSha(latestSha));

            // Download the new JAR to a temp file
            Path tempFile = updateDir.resolve("musicplayer-download.tmp");
            HttpRequest downloadRequest = HttpRequest.newBuilder()
                    .uri(URI.create(JAR_DOWNLOAD_URL))
                    .header("User-Agent", "MusicPlayerMod-AutoUpdater")
                    .timeout(Duration.ofMinutes(5))
                    .GET()
                    .build();

            HttpResponse<Path> downloadResponse = client.send(downloadRequest, HttpResponse.BodyHandlers.ofFile(tempFile));
            if (downloadResponse.statusCode() != 200) {
                MusicPlayerMod.LOGGER.error("[AutoUpdater] Download failed with status {}", downloadResponse.statusCode());
                Files.deleteIfExists(tempFile);
                return;
            }

            // Verify the download is a valid JAR
            if (!isValidJar(tempFile)) {
                MusicPlayerMod.LOGGER.error("[AutoUpdater] Downloaded file is not a valid JAR — discarding");
                Files.deleteIfExists(tempFile);
                return;
            }

            long size = Files.size(tempFile);
            MusicPlayerMod.LOGGER.info("[AutoUpdater] Downloaded {} bytes, verified as valid JAR", size);

            // Replace the mod JAR using atomic rename so the running JVM is never affected.
            // rename() on Linux swaps the directory entry — the old inode stays valid for
            // any process that has it open (the classloader), and the new inode takes the path.
            Path currentJar = resolveCurrentJarPath();
            if (currentJar != null && Files.isRegularFile(currentJar)) {
                if (atomicReplace(tempFile, currentJar)) {
                    Files.deleteIfExists(stagedJar);
                    saveSha(latestSha);
                    MusicPlayerMod.LOGGER.info("[AutoUpdater] Update applied successfully! Restart the server to load the new version.");
                    return;
                }
                MusicPlayerMod.LOGGER.info("[AutoUpdater] Direct replacement failed, staging for next restart");
            }

            // Stage the update — it will be applied on next startup
            Files.move(tempFile, stagedJar, StandardCopyOption.REPLACE_EXISTING);
            saveSha(latestSha);
            MusicPlayerMod.LOGGER.info("[AutoUpdater] Update staged at {} — will be applied on next server start", stagedJar);

        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("[AutoUpdater] Update check failed: {}", e.getMessage());
        }
    }

    private void applyPendingUpdate() {
        if (!Files.isRegularFile(stagedJar)) {
            return;
        }

        try {
            if (!isValidJar(stagedJar)) {
                MusicPlayerMod.LOGGER.warn("[AutoUpdater] Staged update is not a valid JAR — removing");
                Files.deleteIfExists(stagedJar);
                return;
            }

            Path currentJar = resolveCurrentJarPath();
            if (currentJar == null || !Files.isRegularFile(currentJar)) {
                MusicPlayerMod.LOGGER.warn("[AutoUpdater] Cannot locate current mod JAR to apply staged update");
                return;
            }

            if (atomicReplace(stagedJar, currentJar)) {
                MusicPlayerMod.LOGGER.info("[AutoUpdater] Pending update applied from staged file — will be active this run");
            } else {
                MusicPlayerMod.LOGGER.warn("[AutoUpdater] Could not apply staged update (will retry next restart)");
            }
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("[AutoUpdater] Could not apply staged update (will retry next restart): {}", e.getMessage());
        }
    }

    /**
     * Safely replaces {@code target} with {@code source} using an atomic rename.
     * <p>
     * On Linux this performs a {@code rename()} syscall which atomically swaps the
     * directory entry.  The old inode remains valid for any process that already has
     * it open (e.g. the JVM classloader), so the running server is never affected.
     * The new file will be picked up on the next restart.
     * <p>
     * Because {@code source} may live on a different filesystem (the staging dir
     * vs the mods dir), we first copy it to a temp file next to the target so the
     * atomic rename is guaranteed to be on the same filesystem.
     */
    private boolean atomicReplace(Path source, Path target) {
        Path tempNextToTarget = null;
        try {
            // Create a temp file on the SAME filesystem as the target
            tempNextToTarget = target.resolveSibling(target.getFileName() + ".update.tmp");
            Files.copy(source, tempNextToTarget, StandardCopyOption.REPLACE_EXISTING);

            // Atomic rename — swaps directory entry, old inode stays open for running JVM
            try {
                Files.move(tempNextToTarget, target,
                        StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                // Fallback: non-atomic move (still better than in-place overwrite on most systems)
                Files.move(tempNextToTarget, target, StandardCopyOption.REPLACE_EXISTING);
            }

            // Clean up the source file since we successfully replaced
            Files.deleteIfExists(source);
            return true;
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("[AutoUpdater] atomicReplace failed: {}", e.getMessage());
            if (tempNextToTarget != null) {
                try { Files.deleteIfExists(tempNextToTarget); } catch (Exception ignored) {}
            }
            return false;
        }
    }

    private String parseCommitSha(String json) {
        try {
            JsonArray commits = JsonParser.parseString(json).getAsJsonArray();
            if (commits.isEmpty()) {
                return null;
            }
            return commits.get(0).getAsJsonObject().get("sha").getAsString();
        } catch (Exception e) {
            return null;
        }
    }

    private String readStoredSha() {
        try {
            if (Files.isRegularFile(lastCommitFile)) {
                String sha = Files.readString(lastCommitFile).trim();
                return sha.isEmpty() ? null : sha;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private void saveSha(String sha) {
        try {
            Files.writeString(lastCommitFile, sha);
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("[AutoUpdater] Could not persist commit SHA", e);
        }
    }

    private boolean isValidJar(Path path) {
        try (JarFile jar = new JarFile(path.toFile())) {
            return jar.entries().hasMoreElements();
        } catch (Exception e) {
            return false;
        }
    }

    private Path resolveCurrentJarPath() {
        try {
            var codeSource = MusicPlayerMod.class.getProtectionDomain().getCodeSource();
            if (codeSource == null || codeSource.getLocation() == null) {
                return null;
            }
            Path path = Path.of(codeSource.getLocation().toURI());
            if (Files.isRegularFile(path) && path.toString().endsWith(".jar")) {
                return path;
            }
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("[AutoUpdater] Could not resolve current JAR path", e);
        }
        return null;
    }

    private static String shortSha(String sha) {
        return sha.length() > 8 ? sha.substring(0, 8) : sha;
    }
}
