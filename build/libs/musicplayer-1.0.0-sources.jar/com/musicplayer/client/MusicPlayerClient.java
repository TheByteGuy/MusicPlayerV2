package com.musicplayer.client;

import com.musicplayer.audio.DependencyManager;
import com.musicplayer.audio.YouTubeDownloader;
import com.musicplayer.client.gui.CommandScreen;
import com.musicplayer.client.gui.MusicClientUiController;
import com.musicplayer.network.MusicNetworking;
import com.musicplayer.network.MusicPayloads;
import com.musicplayer.util.ModBuildInfo;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;
import java.nio.file.Paths;

public class MusicPlayerClient implements ClientModInitializer {
    private static ClientPlaybackManager playbackManager;
    private static MusicClientUiController uiController;

    @Override
    public void onInitializeClient() {
        MusicNetworking.registerPayloadTypes();

        class_310 client = class_310.method_1551();
        DependencyManager dependencyManager = new DependencyManager(Paths.get("config", "musicplayer", "client"));
        YouTubeDownloader downloader = new YouTubeDownloader(Paths.get("config", "musicplayer", "client", "cache"), dependencyManager);
        playbackManager = new ClientPlaybackManager(downloader, dependencyManager);
        uiController = new MusicClientUiController(client);

        ClientPlayNetworking.registerGlobalReceiver(MusicPayloads.PlayTrackPayload.ID, (payload, context) ->
                context.client().execute(() -> playbackManager.playTrack(payload))
        );
        ClientPlayNetworking.registerGlobalReceiver(MusicPayloads.StopTrackPayload.ID, (payload, context) ->
                context.client().execute(playbackManager::stopTrack)
        );
        ClientPlayNetworking.registerGlobalReceiver(MusicPayloads.PauseTrackPayload.ID, (payload, context) ->
                context.client().execute(() -> playbackManager.setPaused(payload.paused()))
        );
        ClientPlayNetworking.registerGlobalReceiver(MusicPayloads.SetVolumePayload.ID, (payload, context) ->
                context.client().execute(() -> playbackManager.setVolume(payload.volumePercent()))
        );
        ClientPlayNetworking.registerGlobalReceiver(MusicPayloads.OpenMusicUiPayload.ID, (payload, context) ->
                context.client().execute(() -> uiController.open(payload.state()))
        );
        ClientPlayNetworking.registerGlobalReceiver(MusicPayloads.MusicUiStatePayload.ID, (payload, context) ->
                context.client().execute(() -> uiController.update(payload.state()))
        );
        ClientPlayNetworking.registerGlobalReceiver(MusicPayloads.CommandFeedbackPayload.ID, (payload, context) ->
                context.client().execute(() -> CommandScreen.receiveFeedback(payload.message(), payload.error()))
        );

        ClientPlayConnectionEvents.JOIN.register((handler, sender, gameClient) ->
                gameClient.execute(() -> {
                    ClientPlayNetworking.send(MusicPayloads.ClientReadyPayload.INSTANCE);
                    if (ClientPlayNetworking.canSend(MusicPayloads.ClientBuildInfoPayload.ID)) {
                        var buildInfo = ModBuildInfo.current();
                        ClientPlayNetworking.send(new MusicPayloads.ClientBuildInfoPayload(
                                buildInfo.version(),
                                buildInfo.hash()
                        ));
                    }
                    uiController.requestState();
                })
        );
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client1) -> {
            playbackManager.stopTrack();
            uiController.reset();
        });
    }
}
