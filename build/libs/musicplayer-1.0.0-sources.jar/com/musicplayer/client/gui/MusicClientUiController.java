package com.musicplayer.client.gui;

import com.musicplayer.network.MusicPayloads;
import com.musicplayer.ui.MusicUiState;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import java.util.function.Consumer;

public class MusicClientUiController {
    private final class_310 client;
    private MusicUiState state = MusicUiState.EMPTY;

    public MusicClientUiController(class_310 client) {
        this.client = client;
    }

    public void open(class_2487 stateData) {
        state = MusicUiState.fromNbt(stateData);

        if (client.field_1755 instanceof MusicBrowserScreen screen) {
            screen.setState(state);
            return;
        }

        client.method_1507(new MusicBrowserScreen(this, state));
    }

    public void update(class_2487 stateData) {
        state = MusicUiState.fromNbt(stateData);
        if (client.field_1755 instanceof MusicBrowserScreen screen) {
            screen.setState(state);
        }
    }

    public MusicUiState getState() {
        return state;
    }

    public void requestState() {
        if (client.method_1562() == null || !ClientPlayNetworking.canSend(MusicPayloads.MusicUiStateRequestPayload.ID)) {
            return;
        }

        ClientPlayNetworking.send(MusicPayloads.MusicUiStateRequestPayload.INSTANCE);
    }

    public void sendAction(String action) {
        sendAction(action, null);
    }

    public void sendAction(String action, Consumer<class_2487> writer) {
        if (client.method_1562() == null || !ClientPlayNetworking.canSend(MusicPayloads.MusicUiActionPayload.ID)) {
            return;
        }

        class_2487 data = new class_2487();
        data.method_10582("action", action);
        if (writer != null) {
            writer.accept(data);
        }

        ClientPlayNetworking.send(new MusicPayloads.MusicUiActionPayload(data));
    }

    public void reset() {
        state = MusicUiState.EMPTY;
        if (client.field_1755 instanceof MusicBrowserScreen) {
            client.method_1507(null);
        }
    }
}
