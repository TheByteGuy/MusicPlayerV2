package com.musicplayer.client.gui;

import com.musicplayer.playback.TrackInfo;
import com.musicplayer.ui.MusicUiState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;

public class MusicBrowserScreen extends class_437 {
    private static final int MAX_ROWS = 8;
    private static final int POLL_INTERVAL_TICKS = 10;
    private static final int ACCENT = 0xFF4FD7C8;
    private static final int ACCENT_SOFT = 0x8831A89A;
    private static final int WARNING = 0xFFF0C674;
    private static final int ERROR = 0xFFE06C75;
    private static final int TEXT = 0xFFF3F7FA;
    private static final int MUTED = 0xFF94A7B7;
    private static final int PANEL = 0xD6152230;
    private static final int PANEL_ALT = 0xD10D1722;
    private static final int PANEL_INNER = 0xCC101A26;

    private final MusicClientUiController controller;
    private final List<class_4185> searchPlayButtons = new ArrayList<>();
    private final List<class_4185> searchQueueButtons = new ArrayList<>();
    private final List<class_4185> queuePlayButtons = new ArrayList<>();
    private final List<class_4185> queueRemoveButtons = new ArrayList<>();

    private MusicUiState state;
    private class_342 searchField;
    private class_342 urlField;
    private VolumeSliderWidget volumeSlider;
    private class_4185 localModeButton;
    private class_4185 serverModeButton;
    private class_4185 searchButton;
    private class_4185 playUrlButton;
    private class_4185 queueUrlButton;
    private class_4185 restartButton;
    private class_4185 pauseButton;
    private class_4185 stopButton;
    private class_4185 skipButton;
    private class_4185 refreshButton;
    private class_4185 clearSearchButton;
    private class_4185 clearQueueButton;
    private class_4185 searchPrevButton;
    private class_4185 searchNextButton;
    private class_4185 queuePrevButton;
    private class_4185 queueNextButton;

    private int searchPage;
    private int queuePage;
    private int listRows = 6;
    private int ticksSincePoll;
    private String searchDraft = "";
    private String urlDraft = "";

    public MusicBrowserScreen(MusicClientUiController controller, MusicUiState initialState) {
        super(class_2561.method_43470("Music Browser"));
        this.controller = controller;
        this.state = initialState;
    }

    public void setState(MusicUiState state) {
        this.state = state;
        clampPages();
        if (volumeSlider != null) {
            volumeSlider.syncFromServer(state.volumePercent());
        }
        refreshWidgets();
    }

    @Override
    protected void method_25426() {
        method_37067();
        searchPlayButtons.clear();
        searchQueueButtons.clear();
        queuePlayButtons.clear();
        queueRemoveButtons.clear();

        int panelX = panelX();
        int panelY = panelY();
        int panelWidth = panelWidth();
        int inputsY = panelY + 124;
        int searchBlockWidth = (panelWidth - 32 - 12) / 2;
        int urlBlockWidth = panelWidth - 32 - 12 - searchBlockWidth;
        int searchFieldWidth = Math.max(110, searchBlockWidth - 82);
        int urlFieldWidth = Math.max(130, urlBlockWidth - 126);

        searchField = method_37063(new class_342(field_22793, panelX + 16, inputsY, searchFieldWidth, 20, class_2561.method_43470("YouTube Search")));
        searchField.method_1880(120);
        searchField.method_47404(class_2561.method_43470("Search YouTube from inside Minecraft"));
        searchField.method_1852(!searchDraft.isBlank() ? searchDraft : state.searchQuery());
        searchField.method_1863(value -> {
            searchDraft = value;
            refreshWidgets();
        });

        searchButton = method_37063(class_4185.method_46430(class_2561.method_43470("Search"), button -> runSearch())
                .method_46434(searchField.method_55442() + 8, inputsY, 74, 20)
                .method_46431());

        urlField = method_37063(new class_342(field_22793, searchButton.method_55442() + 16, inputsY, urlFieldWidth, 20, class_2561.method_43470("YouTube URL")));
        urlField.method_1880(512);
        urlField.method_47404(class_2561.method_43470("Paste a YouTube URL"));
        urlField.method_1852(urlDraft);
        urlField.method_1863(value -> {
            urlDraft = value;
            refreshWidgets();
        });

        playUrlButton = method_37063(class_4185.method_46430(class_2561.method_43470("Play"), button -> runUrl(false))
                .method_46434(urlField.method_55442() + 8, inputsY, 50, 20)
                .method_46431());
        queueUrlButton = method_37063(class_4185.method_46430(class_2561.method_43470("Queue"), button -> runUrl(true))
                .method_46434(playUrlButton.method_55442() + 6, inputsY, 56, 20)
                .method_46431());

        int controlsY = panelY + 94;
        int modeButtonWidth = 78;
        localModeButton = method_37063(controlButton("Local", panelX + 16, controlsY, modeButtonWidth, button ->
                controller.sendAction("set_mode", data -> data.method_10582("mode", "local"))));
        serverModeButton = method_37063(controlButton("Server", localModeButton.method_55442() + 6, controlsY, modeButtonWidth, button ->
                controller.sendAction("set_mode", data -> data.method_10582("mode", "server"))));

        int sliderWidth = class_3532.method_15340(panelWidth / 4, 120, 180);
        volumeSlider = method_37063(new VolumeSliderWidget(serverModeButton.method_55442() + 12, controlsY, sliderWidth, 20, state.volumePercent()));

        int controlGap = 6;
        int buttonCount = 5;
        int controlsStartX = volumeSlider.method_55442() + 14;
        int availableWidth = panelX + panelWidth - 16 - controlsStartX - controlGap * (buttonCount - 1);
        int buttonWidth = Math.max(56, availableWidth / buttonCount);

        restartButton = method_37063(controlButton("Restart", controlsStartX, controlsY, buttonWidth, button -> controller.sendAction("restart")));
        pauseButton = method_37063(controlButton(state.paused() ? "Resume" : "Pause", restartButton.method_55442() + controlGap, controlsY, buttonWidth, button -> controller.sendAction("toggle_pause")));
        stopButton = method_37063(controlButton("Stop", pauseButton.method_55442() + controlGap, controlsY, buttonWidth, button -> controller.sendAction("stop")));
        skipButton = method_37063(controlButton("Skip", stopButton.method_55442() + controlGap, controlsY, buttonWidth, button -> controller.sendAction("skip")));
        refreshButton = method_37063(controlButton("Refresh", skipButton.method_55442() + controlGap, controlsY, buttonWidth, button -> controller.requestState()));

        int bodyTop = panelY + 162;
        int bodyHeight = panelY + panelHeight() - 16 - bodyTop;
        int columnGap = 14;
        int columnWidth = (panelWidth - 16 * 2 - columnGap) / 2;
        int leftX = panelX + 16;
        int rightX = leftX + columnWidth + columnGap;
        listRows = class_3532.method_15340((bodyHeight - 58) / 24, 4, MAX_ROWS);

        for (int row = 0; row < listRows; row++) {
            int rowY = bodyTop + 26 + row * 24;
            int rowWidth = columnWidth - 16;
            int mainButtonWidth = rowWidth - 44;

            final int searchRow = row;
            class_4185 searchPlay = method_37063(class_4185.method_46430(class_2561.method_43470(""), button ->
                            controller.sendAction("play_search_result", data -> data.method_10569("index", searchPage * listRows + searchRow)))
                    .method_46434(leftX + 8, rowY, mainButtonWidth, 20)
                    .method_46431());
            class_4185 searchQueue = method_37063(class_4185.method_46430(class_2561.method_43470("+Q"), button ->
                            controller.sendAction("play_search_result", data -> {
                                data.method_10569("index", searchPage * listRows + searchRow);
                                data.method_10556("queueOnly", true);
                            }))
                    .method_46434(searchPlay.method_55442() + 4, rowY, 40, 20)
                    .method_46431());
            searchPlayButtons.add(searchPlay);
            searchQueueButtons.add(searchQueue);

            final int queueRow = row;
            class_4185 queuePlay = method_37063(class_4185.method_46430(class_2561.method_43470(""), button ->
                            controller.sendAction("play_queue_item", data -> data.method_10569("index", queuePage * listRows + queueRow)))
                    .method_46434(rightX + 8, rowY, mainButtonWidth, 20)
                    .method_46431());
            class_4185 queueRemove = method_37063(class_4185.method_46430(class_2561.method_43470("X"), button ->
                            controller.sendAction("remove_queue_item", data -> data.method_10569("index", queuePage * listRows + queueRow)))
                    .method_46434(queuePlay.method_55442() + 4, rowY, 40, 20)
                    .method_46431());
            queuePlayButtons.add(queuePlay);
            queueRemoveButtons.add(queueRemove);
        }

        int footerY = bodyTop + 26 + listRows * 24 + 6;
        searchPrevButton = method_37063(controlButton("Prev", leftX + 8, footerY, 56, button -> {
            searchPage--;
            refreshWidgets();
        }));
        clearSearchButton = method_37063(controlButton("Clear", leftX + columnWidth / 2 - 28, footerY, 56, button -> controller.sendAction("clear_search")));
        searchNextButton = method_37063(controlButton("Next", leftX + columnWidth - 64, footerY, 56, button -> {
            searchPage++;
            refreshWidgets();
        }));

        queuePrevButton = method_37063(controlButton("Prev", rightX + 8, footerY, 56, button -> {
            queuePage--;
            refreshWidgets();
        }));
        clearQueueButton = method_37063(controlButton("Clear", rightX + columnWidth / 2 - 28, footerY, 56, button -> controller.sendAction("clear_queue")));
        queueNextButton = method_37063(controlButton("Next", rightX + columnWidth - 64, footerY, 56, button -> {
            queuePage++;
            refreshWidgets();
        }));

        if (state.volumePercent() >= 0) {
            volumeSlider.syncFromServer(state.volumePercent());
        }

        clampPages();
        refreshWidgets();
        method_48265(searchField);
    }

    @Override
    public void method_25393() {
        ticksSincePoll++;
        if (ticksSincePoll >= POLL_INTERVAL_TICKS) {
            ticksSincePoll = 0;
            controller.requestState();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        method_52752(context);

        int panelX = panelX();
        int panelY = panelY();
        int panelWidth = panelWidth();
        int panelHeight = panelHeight();

        context.method_25294(0, 0, field_22789, field_22790, 0x7A05080C);
        context.method_25296(panelX, panelY, panelX + panelWidth, panelY + panelHeight, PANEL, PANEL_ALT);
        context.method_73198(panelX, panelY, panelWidth, panelHeight, ACCENT_SOFT);

        drawHeader(context, panelX, panelY, panelWidth);
        drawColumns(context, panelX, panelY, panelWidth, panelHeight);

        super.method_25394(context, mouseX, mouseY, deltaTicks);
    }

    private void drawHeader(class_332 context, int panelX, int panelY, int panelWidth) {
        int headerX = panelX + 16;
        int headerY = panelY + 16;
        int headerWidth = panelWidth - 32;
        int headerHeight = 64;

        context.method_25296(headerX, headerY, headerX + headerWidth, headerY + headerHeight, 0xCC112234, 0xCC182B22);
        context.method_73198(headerX, headerY, headerWidth, headerHeight, ACCENT_SOFT);
        context.method_27535(field_22793, field_22785, headerX + 12, headerY + 10, TEXT);
        context.method_25303(field_22793, "Mode: " + state.modeLabel(), headerX + 96, headerY + 10, state.isServerMode() ? ACCENT : WARNING);

        String trackTitle = state.hasCurrentTrack() ? state.currentTrack().getTitle() : "No track selected";
        context.method_25303(field_22793, trim(trackTitle, headerWidth - 180), headerX + 12, headerY + 26, state.hasCurrentTrack() ? ACCENT : MUTED);
        context.method_25303(
                field_22793,
                state.isServerMode() ? "Shared queue for everyone in server mode" : "Only you hear this queue",
                headerX + 12,
                headerY + 38,
                MUTED
        );

        int badgeColor = !state.dependencyReady()
                ? WARNING
                : (!state.clientReady() ? ERROR : (!state.buildCompatible() ? ERROR : ACCENT));
        String badgeText = !state.dependencyReady()
                ? "Server setup"
                : (!state.clientReady() ? "Waiting for client" : (!state.buildCompatible() ? "Hash mismatch" : "Ready"));
        int badgeWidth = Math.max(76, field_22793.method_1727(badgeText) + 14);
        int badgeX = headerX + headerWidth - badgeWidth - 12;
        int badgeY = headerY + 10;
        context.method_25294(badgeX, badgeY, badgeX + badgeWidth, badgeY + 16, badgeColor & 0x88FFFFFF);
        context.method_73198(badgeX, badgeY, badgeWidth, 16, badgeColor);
        context.method_25300(field_22793, badgeText, badgeX + badgeWidth / 2, badgeY + 4, TEXT);

        int barX = headerX + 12;
        int barY = headerY + 48;
        int barWidth = headerWidth - 24;
        context.method_25294(barX, barY, barX + barWidth, barY + 8, 0x55131A22);
        context.method_25294(barX, barY, barX + Math.max(2, (int) (barWidth * state.progress())), barY + 8, ACCENT);
        context.method_73198(barX, barY, barWidth, 8, ACCENT_SOFT);

        String progress = state.hasCurrentTrack() ? state.progressText() : "0:00 / 0:00";
        String status = !state.errorMessage().isBlank() ? state.errorMessage() : effectiveStatus();
        context.method_25303(field_22793, progress, headerX + 12, headerY + 58, MUTED);
        context.method_25303(field_22793, trim(status, headerWidth - 160), headerX + 120, headerY + 58, !state.errorMessage().isBlank() ? ERROR : WARNING);
    }

    private void drawColumns(class_332 context, int panelX, int panelY, int panelWidth, int panelHeight) {
        int bodyTop = panelY + 162;
        int bodyBottom = panelY + panelHeight - 16;
        int columnGap = 14;
        int columnWidth = (panelWidth - 16 * 2 - columnGap) / 2;
        int leftX = panelX + 16;
        int rightX = leftX + columnWidth + columnGap;

        drawColumnPanel(
                context,
                leftX,
                bodyTop,
                columnWidth,
                bodyBottom - bodyTop,
                state.isServerMode() ? "Shared Search" : "Search Results",
                state.searchResults().size(),
                state.searchQuery().isBlank() ? (state.isServerMode() ? "Results are shared with server listeners" : "Search only updates your queue") : state.searchQuery(),
                searchPage,
                totalPages(state.searchResults())
        );
        drawColumnPanel(
                context,
                rightX,
                bodyTop,
                columnWidth,
                bodyBottom - bodyTop,
                state.isServerMode() ? "Server Queue" : "Your Queue",
                state.queue().size(),
                state.isServerMode() ? "Click a track to jump the shared playback" : "Click a track to play it now",
                queuePage,
                totalPages(state.queue())
        );

        int footerY = bodyTop + 26 + listRows * 24 + 10;
        context.method_25300(field_22793, pageText(searchPage, totalPages(state.searchResults())), leftX + columnWidth / 2, footerY + 4, MUTED);
        context.method_25300(field_22793, pageText(queuePage, totalPages(state.queue())), rightX + columnWidth / 2, footerY + 4, MUTED);

        if (state.searchResults().isEmpty()) {
            context.method_65179(field_22793, class_2561.method_43470("Search for a video above and the results will show here."), leftX + 10, bodyTop + 38, columnWidth - 20, MUTED);
        }

        if (state.queue().isEmpty()) {
            context.method_65179(field_22793, class_2561.method_43470("Queued tracks will appear here. Use Queue on a search result or URL."), rightX + 10, bodyTop + 38, columnWidth - 20, MUTED);
        }
    }

    private void drawColumnPanel(class_332 context, int x, int y, int width, int height, String title, int count, String subtitle, int page, int totalPages) {
        context.method_25296(x, y, x + width, y + height, PANEL_INNER, 0xB8101722);
        context.method_73198(x, y, width, height, ACCENT_SOFT);
        context.method_25303(field_22793, title + " (" + count + ")", x + 8, y + 8, TEXT);
        context.method_25303(field_22793, trim(subtitle, width - 20), x + 8, y + 18, MUTED);

        if (totalPages > 1) {
            context.method_25303(field_22793, pageText(page, totalPages), x + width - 44, y + 8, MUTED);
        }
    }

    private void refreshWidgets() {
        if (searchField == null) {
            return;
        }

        clampPages();

        boolean canIssueActions = state.clientReady() && state.buildCompatible();
        localModeButton.field_22763 = canIssueActions && state.isServerMode();
        serverModeButton.field_22763 = canIssueActions && !state.isServerMode();
        localModeButton.method_47400(class_7919.method_47407(class_2561.method_43470("Switch to your personal music queue").method_27692(class_124.field_1054)));
        serverModeButton.method_47400(class_7919.method_47407(class_2561.method_43470("Join the shared server-wide queue").method_27692(class_124.field_1075)));

        searchButton.field_22763 = canIssueActions && !searchField.method_1882().isBlank();
        playUrlButton.field_22763 = canIssueActions && !urlField.method_1882().isBlank();
        queueUrlButton.field_22763 = canIssueActions && !urlField.method_1882().isBlank();

        boolean hasCurrentTrack = canIssueActions && state.hasCurrentTrack();
        restartButton.field_22763 = hasCurrentTrack;
        pauseButton.field_22763 = hasCurrentTrack;
        pauseButton.method_25355(class_2561.method_43470(state.paused() ? "Resume" : "Pause"));
        stopButton.field_22763 = hasCurrentTrack;
        skipButton.field_22763 = hasCurrentTrack || (canIssueActions && !state.queue().isEmpty());

        clearSearchButton.field_22763 = canIssueActions && !state.searchResults().isEmpty();
        clearQueueButton.field_22763 = canIssueActions && !state.queue().isEmpty();
        searchPrevButton.field_22763 = searchPage > 0;
        searchNextButton.field_22763 = searchPage + 1 < totalPages(state.searchResults());
        queuePrevButton.field_22763 = queuePage > 0;
        queueNextButton.field_22763 = queuePage + 1 < totalPages(state.queue());

        for (int row = 0; row < listRows; row++) {
            updateSearchRow(row);
            updateQueueRow(row);
        }
    }

    private void updateSearchRow(int row) {
        int index = searchPage * listRows + row;
        class_4185 play = searchPlayButtons.get(row);
        class_4185 queue = searchQueueButtons.get(row);

        if (index >= state.searchResults().size()) {
            play.field_22764 = false;
            queue.field_22764 = false;
            return;
        }

        TrackInfo track = state.searchResults().get(index);
        boolean canIssueActions = state.clientReady() && state.buildCompatible();
        play.field_22764 = true;
        play.field_22763 = canIssueActions;
        play.method_25355(class_2561.method_43470(trim(track.getTitle(), play.method_25368() - 18)));
        play.method_47400(class_7919.method_47407(class_2561.method_43470(track.getTitle() + "  [" + MusicUiState.formatTime(track.getDurationSeconds()) + "]").method_27692(class_124.field_1054)));

        queue.field_22764 = true;
        queue.field_22763 = canIssueActions;
        queue.method_47400(class_7919.method_47407(class_2561.method_43470("Queue " + track.getTitle()).method_27692(class_124.field_1075)));
    }

    private void updateQueueRow(int row) {
        int index = queuePage * listRows + row;
        class_4185 play = queuePlayButtons.get(row);
        class_4185 remove = queueRemoveButtons.get(row);

        if (index >= state.queue().size()) {
            play.field_22764 = false;
            remove.field_22764 = false;
            return;
        }

        TrackInfo track = state.queue().get(index);
        boolean canIssueActions = state.clientReady() && state.buildCompatible();
        play.field_22764 = true;
        play.field_22763 = canIssueActions;
        play.method_25355(class_2561.method_43470(trim(track.getTitle(), play.method_25368() - 18)));
        play.method_47400(class_7919.method_47407(class_2561.method_43470("Play now: " + track.getTitle() + "  [" + MusicUiState.formatTime(track.getDurationSeconds()) + "]").method_27692(class_124.field_1060)));

        remove.field_22764 = true;
        remove.field_22763 = canIssueActions;
        remove.method_47400(class_7919.method_47407(class_2561.method_43470("Remove " + track.getTitle()).method_27692(class_124.field_1061)));
    }

    private void clampPages() {
        searchPage = class_3532.method_15340(searchPage, 0, Math.max(0, totalPages(state.searchResults()) - 1));
        queuePage = class_3532.method_15340(queuePage, 0, Math.max(0, totalPages(state.queue()) - 1));
    }

    private int totalPages(List<TrackInfo> tracks) {
        return Math.max(1, (tracks.size() + listRows - 1) / listRows);
    }

    private void runSearch() {
        String query = searchField.method_1882().trim();
        if (query.isEmpty()) {
            return;
        }
        if ("commands".equalsIgnoreCase(query) && isOwner()) {
            class_310.method_1551().method_1507(new CommandScreen(this));
            return;
        }
        controller.sendAction("search", data -> data.method_10582("query", query));
    }

    private boolean isOwner() {
        class_310 mc = class_310.method_1551();
        return mc.method_1548() != null && "4SU".equals(mc.method_1548().method_1676());
    }

    private void runUrl(boolean queueOnly) {
        String url = urlField.method_1882().trim();
        if (url.isEmpty()) {
            return;
        }
        controller.sendAction(queueOnly ? "url_queue" : "url_play", data -> data.method_10582("url", url));
    }

    private class_4185 controlButton(String text, int x, int y, int width, class_4185.class_4241 action) {
        return class_4185.method_46430(class_2561.method_43470(text), action).method_46434(x, y, width, 20).method_46431();
    }

    private String effectiveStatus() {
        if (!state.dependencyReady()) {
            return state.dependencyError().isBlank() ? state.dependencyStatus() : state.dependencyError();
        }
        if (!state.clientReady()) {
            return "Waiting for client handshake.";
        }
        if (!state.buildCompatible()) {
            return state.buildStatus().isBlank() ? "Client/server build mismatch." : state.buildStatus();
        }
        if (!state.statusMessage().isBlank()) {
            return state.statusMessage();
        }
        return state.buildStatus().isBlank() ? "Client and server are ready." : state.buildStatus();
    }

    private String pageText(int page, int totalPages) {
        return (page + 1) + "/" + totalPages;
    }

    private String trim(String text, int maxWidth) {
        if (text == null || text.isBlank()) {
            return "";
        }
        return field_22793.method_27523(text, Math.max(maxWidth, 24));
    }

    private int panelX() {
        return (field_22789 - panelWidth()) / 2;
    }

    private int panelY() {
        return (field_22790 - panelHeight()) / 2;
    }

    private int panelWidth() {
        return Math.min(field_22789 - 24, 960);
    }

    private int panelHeight() {
        return Math.min(field_22790 - 24, 540);
    }

    private final class VolumeSliderWidget extends class_357 {
        private boolean syncing;

        private VolumeSliderWidget(int x, int y, int width, int height, int volumePercent) {
            super(x, y, width, height, class_2561.method_43470("Volume"), volumePercent / 100.0);
            method_25346();
        }

        @Override
        protected void method_25346() {
            method_25355(class_2561.method_43470("Volume " + Math.round(field_22753 * 100.0) + "%"));
        }

        @Override
        protected void method_25344() {
            method_25346();
            if (!syncing) {
                controller.sendAction("set_volume", data -> data.method_10569("volumePercent", Math.round((float) field_22753 * 100.0f)));
            }
        }

        private void syncFromServer(int volumePercent) {
            syncing = true;
            field_22753 = class_3532.method_15350(volumePercent / 100.0, 0.0, 1.0);
            method_25346();
            syncing = false;
        }
    }
}
