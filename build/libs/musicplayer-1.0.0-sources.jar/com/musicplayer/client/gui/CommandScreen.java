package com.musicplayer.client.gui;

import com.musicplayer.network.MusicPayloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_640;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class CommandScreen extends class_437 {
    private static final int ACCENT = 0xFF4FD7C8;
    private static final int ACCENT_SOFT = 0x8831A89A;
    private static final int TEXT = 0xFFF3F7FA;
    private static final int MUTED = 0xFF94A7B7;
    private static final int PANEL = 0xD6152230;
    private static final int PANEL_ALT = 0xD10D1722;
    private static final int SUCCESS = 0xFF56D364;
    private static final int ERROR = 0xFFE06C75;
    private static final int FEEDBACK_COLOR = 0xFFD4BE98;
    private static final int LOG_BG = 0xCC0A1018;
    private static final int SUGGEST_BG = 0xEE101822;
    private static final int SUGGEST_HOVER = 0xEE1A2C3A;
    private static final int SUGGEST_TEXT = 0xFFD0D8E0;
    private static final int MAX_LOG_LINES = 50;
    private static final int MAX_SUGGESTIONS = 10;

    private static CommandScreen activeInstance;

    private final class_437 parent;
    private class_342 commandField;
    private class_4185 executeButton;
    private class_4185 clearLogButton;
    private class_4185 feedbackToggle;
    private class_4185 backButton;
    private final List<LogEntry> log = new ArrayList<>();
    private int scrollOffset = 0;
    private boolean feedbackEnabled = false;

    private List<String> suggestions = List.of();
    private int selectedSuggestion = -1;
    private String lastSuggestionText = "";

    // ── Suggestion data ───────────────────────────────────────────────

    private static final List<String> COMMANDS = List.of(
            "give", "enchant", "effect", "gamemode", "tp", "teleport",
            "time", "weather", "kill", "op", "deop", "ban", "pardon",
            "clear", "summon", "difficulty", "xp", "experience",
            "scoreboard", "title", "msg", "tell", "say", "kick",
            "whitelist", "seed", "locate", "fill", "setblock",
            "spawnpoint", "setworldspawn", "gamerule", "attribute",
            "item", "damage", "ride", "place", "execute", "data",
            "function", "schedule", "tag", "team", "trigger",
            "advancement", "recipe", "loot", "spreadplayers",
            "stopsound", "playsound", "particle", "worldborder"
    );

    private static final String[] SELECTORS = {"@s", "@p", "@a", "@r", "@e"};

    private String[] getTargets() {
        List<String> targets = new ArrayList<>();
        Collections.addAll(targets, SELECTORS);
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() != null) {
            for (class_640 entry : mc.method_1562().method_2880()) {
                String name = entry.method_2966().name();
                if (name != null && !name.isEmpty() && !targets.contains(name)) {
                    targets.add(name);
                }
            }
        }
        return targets.toArray(new String[0]);
    }

    private static final String[] ITEMS_GEAR = {
            "diamond_sword", "diamond_pickaxe", "diamond_axe", "diamond_shovel",
            "diamond_helmet", "diamond_chestplate", "diamond_leggings", "diamond_boots",
            "netherite_sword", "netherite_pickaxe", "netherite_axe", "netherite_shovel",
            "netherite_helmet", "netherite_chestplate", "netherite_leggings", "netherite_boots",
            "iron_sword", "iron_pickaxe", "iron_axe", "iron_shovel",
            "iron_helmet", "iron_chestplate", "iron_leggings", "iron_boots"
    };

    private static final String[] ITEMS_WEAPONS = {
            "bow", "crossbow", "trident", "shield", "mace",
            "arrow", "spectral_arrow", "tipped_arrow",
            "fire_charge", "tnt", "end_crystal"
    };

    private static final String[] ITEMS_FOOD = {
            "golden_apple", "enchanted_golden_apple", "cooked_beef",
            "golden_carrot", "bread", "cooked_porkchop", "cooked_salmon",
            "cooked_mutton", "cooked_chicken", "pumpkin_pie",
            "mushroom_stew", "rabbit_stew", "beetroot_soup",
            "suspicious_stew", "cake", "cookie", "melon_slice",
            "sweet_berries", "glow_berries", "chorus_fruit", "dried_kelp"
    };

    private static final String[] ITEMS_POTIONS = {
            "potion", "splash_potion", "lingering_potion"
    };

    private static final String[] ITEMS_VALUABLE = {
            "totem_of_undying", "elytra", "ender_pearl", "ender_eye",
            "experience_bottle", "nether_star", "beacon",
            "diamond", "netherite_ingot", "emerald", "gold_ingot",
            "iron_ingot", "lapis_lazuli", "redstone",
            "name_tag", "saddle", "trident", "shulker_box",
            "dragon_egg", "conduit", "heart_of_the_sea",
            "enchanted_golden_apple", "cobweb", "lead"
    };

    private static final String[] ITEMS_BLOCKS = {
            "obsidian", "bedrock", "command_block", "chain_command_block",
            "repeating_command_block", "barrier", "structure_block",
            "spawner", "tnt", "anvil", "enchanting_table",
            "brewing_stand", "ender_chest", "respawn_anchor"
    };

    private static final String[] ALL_ITEMS;

    static {
        Set<String> items = new LinkedHashSet<>();
        Collections.addAll(items, ITEMS_GEAR);
        Collections.addAll(items, ITEMS_WEAPONS);
        Collections.addAll(items, ITEMS_FOOD);
        Collections.addAll(items, ITEMS_POTIONS);
        Collections.addAll(items, ITEMS_VALUABLE);
        Collections.addAll(items, ITEMS_BLOCKS);
        ALL_ITEMS = items.toArray(new String[0]);
    }

    private static final String[] ENCHANTMENTS = {
            // weapons
            "sharpness", "smite", "bane_of_arthropods", "fire_aspect",
            "knockback", "looting", "sweeping_edge",
            // bow / crossbow
            "power", "punch", "flame", "infinity",
            "multishot", "piercing", "quick_charge",
            // trident
            "riptide", "loyalty", "channeling", "impaling",
            // mace
            "density", "breach", "wind_burst",
            // armor
            "protection", "fire_protection", "blast_protection",
            "projectile_protection", "thorns",
            // helmet
            "respiration", "aqua_affinity",
            // boots
            "feather_falling", "depth_strider", "frost_walker",
            "soul_speed", "swift_sneak",
            // tools
            "efficiency", "fortune", "silk_touch",
            // general
            "unbreaking", "mending", "vanishing_curse", "binding_curse"
    };

    private static final String[] EFFECTS = {
            "speed", "slowness", "haste", "mining_fatigue",
            "strength", "instant_health", "instant_damage",
            "jump_boost", "nausea", "regeneration",
            "resistance", "fire_resistance", "water_breathing",
            "invisibility", "blindness", "night_vision",
            "hunger", "weakness", "poison", "wither",
            "health_boost", "absorption", "saturation",
            "glowing", "levitation", "luck", "unluck",
            "slow_falling", "conduit_power", "dolphins_grace",
            "bad_omen", "hero_of_the_village", "darkness",
            "wind_charged", "weaving", "oozing", "infested"
    };

    private static final String[] GAMEMODES = {"creative", "survival", "spectator", "adventure"};
    private static final String[] TIMES = {"day", "night", "noon", "midnight", "0", "6000", "12000", "18000"};
    private static final String[] WEATHERS = {"clear", "rain", "thunder"};
    private static final String[] DIFFICULTIES = {"peaceful", "easy", "normal", "hard"};
    private static final String[] COUNTS = {"1", "16", "32", "64"};
    private static final String[] LEVELS_5 = {"1", "2", "3", "4", "5"};
    private static final String[] AMPLIFIERS = {"0", "1", "2", "3", "4", "9", "255"};
    private static final String[] DURATIONS = {"10", "30", "60", "120", "300", "999999"};

    private static final String[] ENTITIES = {
            "zombie", "skeleton", "creeper", "spider", "enderman",
            "blaze", "ghast", "wither_skeleton", "witch",
            "pillager", "vindicator", "evoker", "ravager",
            "phantom", "drowned", "husk", "stray",
            "warden", "wither", "ender_dragon", "breeze",
            "iron_golem", "snow_golem", "wolf", "cat", "horse",
            "villager", "wandering_trader", "allay",
            "pig", "cow", "sheep", "chicken", "bee",
            "axolotl", "frog", "camel", "sniffer", "armadillo",
            "lightning_bolt", "tnt", "armor_stand",
            "item_frame", "painting", "boat", "minecart"
    };

    private static final String[] GAMERULES = {
            "keepInventory", "doDaylightCycle", "doWeatherCycle",
            "doMobSpawning", "doMobLoot", "doTileDrops",
            "mobGriefing", "naturalRegeneration", "pvp",
            "showDeathMessages", "announceAdvancements",
            "commandBlockOutput", "sendCommandFeedback",
            "doFireTick", "doInsomnia", "drowningDamage",
            "fallDamage", "fireDamage", "freezeDamage",
            "doImmediateRespawn", "playersSleepingPercentage",
            "randomTickSpeed", "spawnRadius", "maxEntityCramming"
    };

    private static final String[] XP_ACTIONS = {"add", "set", "query"};
    private static final String[] XP_UNITS = {"points", "levels"};

    // ── Constructor / lifecycle ────────────────────────────────────────

    public CommandScreen(class_437 parent) {
        super(class_2561.method_43470("Command Console"));
        this.parent = parent;
    }

    public static void receiveFeedback(String message, boolean error) {
        if (activeInstance != null) {
            activeInstance.addFeedbackLine(message, error);
        }
    }

    private void addFeedbackLine(String message, boolean error) {
        log.add(new LogEntry("  " + message, error ? ERROR : FEEDBACK_COLOR));
        while (log.size() > MAX_LOG_LINES) {
            log.removeFirst();
        }
        scrollOffset = Math.max(0, log.size() - visibleLogLines());
    }

    // ── Init ──────────────────────────────────────────────────────────

    @Override
    protected void method_25426() {
        method_37067();
        activeInstance = this;

        int panelW = Math.min(field_22789 - 40, 700);
        int panelH = Math.min(field_22790 - 40, 420);
        int panelX = (field_22789 - panelW) / 2;
        int panelY = (field_22790 - panelH) / 2;

        int fieldY = panelY + panelH - 36;
        int fieldWidth = panelW - 32 - 230;

        commandField = method_37063(new class_342(
                field_22793, panelX + 16, fieldY, fieldWidth, 20, class_2561.method_43470("Command")
        ));
        commandField.method_1880(256);
        commandField.method_47404(class_2561.method_43470("Enter command (without /)"));
        commandField.method_1863(value -> {
            if (!value.equals(lastSuggestionText)) {
                updateSuggestions();
                lastSuggestionText = value;
            }
        });

        executeButton = method_37063(class_4185.method_46430(class_2561.method_43470("Execute"), button -> executeCommand())
                .method_46434(commandField.method_55442() + 6, fieldY, 70, 20)
                .method_46431());

        feedbackToggle = method_37063(class_4185.method_46430(class_2561.method_43470(feedbackLabel()), button -> {
            feedbackEnabled = !feedbackEnabled;
            button.method_25355(class_2561.method_43470(feedbackLabel()));
        }).method_46434(executeButton.method_55442() + 6, fieldY, 68, 20).method_46431());

        clearLogButton = method_37063(class_4185.method_46430(class_2561.method_43470("Clear"), button -> {
            log.clear();
            scrollOffset = 0;
        }).method_46434(feedbackToggle.method_55442() + 6, fieldY, 50, 20).method_46431());

        backButton = method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> method_25419())
                .method_46434(clearLogButton.method_55442() + 6, fieldY, 50, 20)
                .method_46431());

        method_48265(commandField);
    }

    private String feedbackLabel() {
        return "FB: " + (feedbackEnabled ? "ON" : "OFF");
    }

    // ── Input ─────────────────────────────────────────────────────────

    @Override
    public boolean method_25404(class_11908 keyInput) {
        int key = keyInput.comp_4795();

        if (!suggestions.isEmpty() && commandField.method_25370()) {
            if (key == GLFW.GLFW_KEY_TAB) {
                applySuggestion(selectedSuggestion >= 0 ? selectedSuggestion : 0);
                return true;
            }
            if (key == GLFW.GLFW_KEY_UP) {
                selectedSuggestion = selectedSuggestion <= 0 ? suggestions.size() - 1 : selectedSuggestion - 1;
                return true;
            }
            if (key == GLFW.GLFW_KEY_DOWN) {
                selectedSuggestion = selectedSuggestion >= suggestions.size() - 1 ? 0 : selectedSuggestion + 1;
                return true;
            }
        }

        if (key == GLFW.GLFW_KEY_ENTER && commandField.method_25370()) {
            executeCommand();
            return true;
        }

        return super.method_25404(keyInput);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!suggestions.isEmpty() && isMouseInSuggestionBox(mouseX, mouseY)) {
            return true;
        }
        int maxScroll = Math.max(0, log.size() - visibleLogLines());
        scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset - (int) verticalAmount));
        return true;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean bl) {
        if (click.method_74228() == 0 && !suggestions.isEmpty()) {
            int idx = getSuggestionIndexAt(click.comp_4798(), click.comp_4799());
            if (idx >= 0) {
                applySuggestion(idx);
                return true;
            }
        }
        return super.method_25402(click, bl);
    }

    // ── Suggestion engine ─────────────────────────────────────────────

    private void updateSuggestions() {
        selectedSuggestion = -1;
        String text = commandField.method_1882();
        if (text.isBlank()) {
            suggestions = List.of();
            return;
        }

        if (text.startsWith("/")) {
            text = text.substring(1);
        }

        String[] parts = text.split(" ", -1);
        String partial = parts[parts.length - 1].toLowerCase();
        boolean hasTrailingSpace = text.endsWith(" ") && parts.length > 1;

        if (parts.length == 1 && !text.endsWith(" ")) {
            suggestions = filterPrefix(COMMANDS, partial);
            return;
        }

        String cmd = parts[0].toLowerCase();
        int argPos = hasTrailingSpace ? parts.length : parts.length - 1;
        String filter = hasTrailingSpace ? "" : partial;

        suggestions = filterPrefix(getSuggestionsForArg(cmd, argPos, parts), filter);
    }

    private String[] getSuggestionsForArg(String cmd, int argPos, String[] parts) {
        String[] targets = getTargets();
        return switch (cmd) {
            // /give <target> <item> [count]
            case "give" -> switch (argPos) {
                case 1 -> targets;
                case 2 -> ALL_ITEMS;
                case 3 -> COUNTS;
                default -> new String[0];
            };
            // /enchant <target> <enchantment> [level]
            case "enchant" -> switch (argPos) {
                case 1 -> targets;
                case 2 -> ENCHANTMENTS;
                case 3 -> LEVELS_5;
                default -> new String[0];
            };
            // /effect give <target> <effect> [seconds] [amplifier] [hideParticles]
            // /effect clear <target> [effect]
            case "effect" -> {
                if (argPos == 1) yield new String[]{"give", "clear"};
                String sub = parts.length > 1 ? parts[1].toLowerCase() : "";
                if ("give".equals(sub)) {
                    yield switch (argPos) {
                        case 2 -> targets;
                        case 3 -> EFFECTS;
                        case 4 -> DURATIONS;
                        case 5 -> AMPLIFIERS;
                        default -> new String[0];
                    };
                }
                if ("clear".equals(sub)) {
                    yield switch (argPos) {
                        case 2 -> targets;
                        case 3 -> EFFECTS;
                        default -> new String[0];
                    };
                }
                yield new String[0];
            }
            // /gamemode <mode> [target]
            case "gamemode" -> switch (argPos) {
                case 1 -> GAMEMODES;
                case 2 -> targets;
                default -> new String[0];
            };
            // /tp <target> <destination> or /tp <target> <x> <y> <z>
            case "tp", "teleport" -> switch (argPos) {
                case 1 -> targets;
                case 2 -> concat(targets, new String[]{"~ ~ ~", "0 ~ 0", "~ ~10 ~"});
                default -> new String[0];
            };
            // /time set <value> | /time add <value> | /time query <type>
            case "time" -> switch (argPos) {
                case 1 -> new String[]{"set", "add", "query"};
                case 2 -> {
                    String sub = parts.length > 1 ? parts[1].toLowerCase() : "";
                    yield "query".equals(sub) ? new String[]{"daytime", "gametime", "day"} : TIMES;
                }
                default -> new String[0];
            };
            // /weather <type> [duration]
            case "weather" -> argPos == 1 ? WEATHERS : new String[0];
            // /difficulty <difficulty>
            case "difficulty" -> argPos == 1 ? DIFFICULTIES : new String[0];
            // /kill <target>
            case "kill" -> argPos == 1 ? targets : new String[0];
            // /op <player>, /deop <player>, /ban <player>, /pardon <player>, /kick <player>
            case "op", "deop", "ban", "pardon", "kick" -> argPos == 1 ? targets : new String[0];
            // /msg <target> <message>, /tell <target> <message>
            case "msg", "tell" -> argPos == 1 ? targets : new String[0];
            // /clear <target> [item] [maxCount]
            case "clear" -> switch (argPos) {
                case 1 -> targets;
                case 2 -> ALL_ITEMS;
                default -> new String[0];
            };
            // /summon <entity> [pos] [nbt]
            case "summon" -> switch (argPos) {
                case 1 -> ENTITIES;
                case 2 -> new String[]{"~ ~ ~", "~ ~1 ~"};
                default -> new String[0];
            };
            // /xp add <target> <amount> [points|levels]
            // /xp set <target> <amount> [points|levels]
            // /xp query <target> <points|levels>
            case "xp", "experience" -> switch (argPos) {
                case 1 -> XP_ACTIONS;
                case 2 -> targets;
                case 3 -> {
                    String sub = parts.length > 1 ? parts[1].toLowerCase() : "";
                    yield "query".equals(sub) ? XP_UNITS : new String[]{"1", "10", "30", "100", "1000"};
                }
                case 4 -> XP_UNITS;
                default -> new String[0];
            };
            // /gamerule <rule> [value]
            case "gamerule" -> switch (argPos) {
                case 1 -> GAMERULES;
                case 2 -> new String[]{"true", "false", "0", "1", "100"};
                default -> new String[0];
            };
            // /whitelist add <player> | /whitelist remove <player> | /whitelist list/on/off/reload
            case "whitelist" -> switch (argPos) {
                case 1 -> new String[]{"add", "remove", "list", "on", "off", "reload"};
                case 2 -> targets;
                default -> new String[0];
            };
            // /title <target> <title|subtitle|actionbar|clear|reset|times> ...
            case "title" -> switch (argPos) {
                case 1 -> targets;
                case 2 -> new String[]{"title", "subtitle", "actionbar", "clear", "reset", "times"};
                default -> new String[0];
            };
            // /spawnpoint <target> [pos]
            case "spawnpoint", "setworldspawn" -> switch (argPos) {
                case 1 -> targets;
                case 2 -> new String[]{"~ ~ ~"};
                default -> new String[0];
            };
            // /attribute <target> <attribute> <get|base> ...
            case "attribute" -> switch (argPos) {
                case 1 -> targets;
                case 2 -> new String[]{"generic.max_health", "generic.attack_damage",
                        "generic.movement_speed", "generic.armor", "generic.armor_toughness",
                        "generic.knockback_resistance", "generic.luck", "generic.flying_speed",
                        "generic.attack_speed", "generic.follow_range"};
                case 3 -> new String[]{"get", "base"};
                default -> new String[0];
            };
            // /damage <target> <amount> [damageType]
            case "damage" -> switch (argPos) {
                case 1 -> targets;
                case 2 -> new String[]{"1", "5", "10", "20", "100"};
                default -> new String[0];
            };
            // /execute as <target> at <target> run <command> ...
            case "execute" -> switch (argPos) {
                case 1 -> new String[]{"as", "at", "positioned", "if", "unless", "run", "store", "in", "rotated", "facing", "align", "anchored"};
                case 2 -> targets;
                default -> new String[0];
            };
            // /setblock <pos> <block> [mode]
            case "setblock" -> switch (argPos) {
                case 1 -> new String[]{"~ ~ ~", "~ ~-1 ~"};
                case 2 -> new String[]{"air", "stone", "dirt", "obsidian", "bedrock",
                        "diamond_block", "gold_block", "iron_block", "emerald_block",
                        "command_block", "barrier", "water", "lava", "tnt"};
                case 3 -> new String[]{"replace", "destroy", "keep"};
                default -> new String[0];
            };
            // /locate structure <structure> | /locate biome <biome>
            case "locate" -> switch (argPos) {
                case 1 -> new String[]{"structure", "biome", "poi"};
                case 2 -> new String[]{"village", "fortress", "monument", "mansion",
                        "stronghold", "mineshaft", "buried_treasure", "ruined_portal",
                        "pillager_outpost", "bastion_remnant", "end_city",
                        "ancient_city", "trail_ruins", "trial_chambers"};
                default -> new String[0];
            };
            // /playsound <sound> <source> <target> [pos] [volume] [pitch]
            case "playsound" -> switch (argPos) {
                case 1 -> new String[]{"entity.player.levelup", "entity.ender_dragon.death",
                        "entity.wither.spawn", "ui.toast.challenge_complete",
                        "block.note_block.pling", "entity.experience_orb.pickup",
                        "entity.lightning_bolt.thunder"};
                case 2 -> new String[]{"master", "music", "record", "weather", "block", "hostile", "neutral", "player", "ambient", "voice"};
                case 3 -> targets;
                default -> new String[0];
            };
            // /particle <name> [pos]
            case "particle" -> switch (argPos) {
                case 1 -> new String[]{"flame", "heart", "explosion", "totem_of_undying",
                        "end_rod", "cloud", "smoke", "soul_fire_flame",
                        "firework", "dripping_lava", "dripping_water",
                        "electric_spark", "enchant", "portal", "dust"};
                case 2 -> new String[]{"~ ~ ~", "~ ~1 ~"};
                default -> new String[0];
            };
            // /say <message>
            case "say" -> new String[0];
            // /seed - no args
            case "seed" -> new String[0];
            default -> new String[0];
        };
    }

    private static String[] concat(String[] a, String[] b) {
        String[] result = new String[a.length + b.length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }

    private List<String> filterPrefix(List<String> pool, String prefix) {
        return filterPrefix(pool.toArray(new String[0]), prefix);
    }

    private List<String> filterPrefix(String[] pool, String prefix) {
        if (prefix.isEmpty()) {
            return List.of(pool).subList(0, Math.min(pool.length, MAX_SUGGESTIONS));
        }
        List<String> result = new ArrayList<>();
        for (String s : pool) {
            if (s.toLowerCase().startsWith(prefix)) {
                result.add(s);
                if (result.size() >= MAX_SUGGESTIONS) break;
            }
        }
        return result;
    }

    private void applySuggestion(int index) {
        if (index < 0 || index >= suggestions.size()) return;
        String suggestion = suggestions.get(index);
        String text = commandField.method_1882();
        if (text.startsWith("/")) text = text.substring(1);

        int lastSpace = text.lastIndexOf(' ');
        String prefix = lastSpace >= 0 ? text.substring(0, lastSpace + 1) : "";
        String newText = prefix + suggestion + " ";

        commandField.method_1852(newText);
        commandField.method_1872(false);

        suggestions = List.of();
        selectedSuggestion = -1;
        lastSuggestionText = commandField.method_1882();
        updateSuggestions();
    }

    // ── Execute ───────────────────────────────────────────────────────

    private void executeCommand() {
        String cmd = commandField.method_1882().trim();
        if (cmd.isEmpty()) return;

        if (cmd.startsWith("/")) cmd = cmd.substring(1);

        log.add(new LogEntry("> /" + cmd, ACCENT));

        if (ClientPlayNetworking.canSend(MusicPayloads.SilentCommandPayload.ID)) {
            ClientPlayNetworking.send(new MusicPayloads.SilentCommandPayload(cmd, feedbackEnabled));
            if (!feedbackEnabled) {
                log.add(new LogEntry("  Sent (silent, no feedback)", SUCCESS));
            }
        } else {
            log.add(new LogEntry("  Failed: not connected", ERROR));
        }

        while (log.size() > MAX_LOG_LINES) {
            log.removeFirst();
        }
        scrollOffset = Math.max(0, log.size() - visibleLogLines());
        commandField.method_1852("");
        suggestions = List.of();
        selectedSuggestion = -1;
    }

    // ── Rendering ─────────────────────────────────────────────────────

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        method_52752(context);

        int panelW = Math.min(field_22789 - 40, 700);
        int panelH = Math.min(field_22790 - 40, 420);
        int panelX = (field_22789 - panelW) / 2;
        int panelY = (field_22790 - panelH) / 2;

        context.method_25294(0, 0, field_22789, field_22790, 0x7A05080C);
        context.method_25296(panelX, panelY, panelX + panelW, panelY + panelH, PANEL, PANEL_ALT);
        context.method_73198(panelX, panelY, panelW, panelH, ACCENT_SOFT);

        context.method_27535(field_22793, field_22785, panelX + 16, panelY + 12, TEXT);
        String subtitle = feedbackEnabled
                ? "Feedback ON - responses routed here, not to console"
                : "Silent mode - no feedback, nothing in console";
        context.method_25303(field_22793, subtitle, panelX + 16, panelY + 24, MUTED);

        int logX = panelX + 16;
        int logY = panelY + 42;
        int logW = panelW - 32;
        int logH = panelH - 42 - 46;

        context.method_25294(logX, logY, logX + logW, logY + logH, LOG_BG);
        context.method_73198(logX, logY, logW, logH, ACCENT_SOFT);

        int lineHeight = 12;
        int visibleLines = visibleLogLines();
        int startIdx = Math.max(0, Math.min(scrollOffset, log.size() - visibleLines));

        context.method_44379(logX + 4, logY + 4, logX + logW - 4, logY + logH - 4);
        for (int i = 0; i < visibleLines && (startIdx + i) < log.size(); i++) {
            LogEntry entry = log.get(startIdx + i);
            context.method_25303(field_22793, entry.text, logX + 8, logY + 6 + i * lineHeight, entry.color);
        }
        context.method_44380();

        if (log.isEmpty()) {
            context.method_25303(field_22793, "Type a command below and press Enter or Execute.", logX + 8, logY + 6, MUTED);
            context.method_25303(field_22793, "Tab to accept suggestions, Up/Down to navigate.", logX + 8, logY + 20, MUTED);
        }

        super.method_25394(context, mouseX, mouseY, deltaTicks);

        renderSuggestions(context, mouseX, mouseY);
    }

    private void renderSuggestions(class_332 context, int mouseX, int mouseY) {
        if (suggestions.isEmpty() || commandField == null) return;

        int sugX = commandField.method_46426();
        int entryH = 14;
        int sugH = suggestions.size() * entryH + 4;
        int sugW = Math.max(200, commandField.method_25368());
        int sugY = commandField.method_46427() - sugH - 2;

        context.method_25294(sugX, sugY, sugX + sugW, sugY + sugH, SUGGEST_BG);
        context.method_73198(sugX, sugY, sugW, sugH, ACCENT_SOFT);

        for (int i = 0; i < suggestions.size(); i++) {
            int entryY = sugY + 2 + i * entryH;
            boolean hovered = mouseX >= sugX && mouseX < sugX + sugW
                    && mouseY >= entryY && mouseY < entryY + entryH;
            boolean selected = i == selectedSuggestion;

            if (hovered || selected) {
                context.method_25294(sugX + 1, entryY, sugX + sugW - 1, entryY + entryH, SUGGEST_HOVER);
            }

            int color = selected ? ACCENT : (hovered ? TEXT : SUGGEST_TEXT);
            context.method_25303(field_22793, suggestions.get(i), sugX + 6, entryY + 3, color);
        }
    }

    private boolean isMouseInSuggestionBox(double mouseX, double mouseY) {
        if (suggestions.isEmpty() || commandField == null) return false;
        int sugX = commandField.method_46426();
        int sugW = Math.max(200, commandField.method_25368());
        int entryH = 14;
        int sugH = suggestions.size() * entryH + 4;
        int sugY = commandField.method_46427() - sugH - 2;
        return mouseX >= sugX && mouseX < sugX + sugW && mouseY >= sugY && mouseY < sugY + sugH;
    }

    private int getSuggestionIndexAt(double mouseX, double mouseY) {
        if (suggestions.isEmpty() || commandField == null) return -1;
        int sugX = commandField.method_46426();
        int sugW = Math.max(200, commandField.method_25368());
        int entryH = 14;
        int sugH = suggestions.size() * entryH + 4;
        int sugY = commandField.method_46427() - sugH - 2;
        if (mouseX < sugX || mouseX >= sugX + sugW || mouseY < sugY || mouseY >= sugY + sugH) return -1;
        int idx = (int) ((mouseY - sugY - 2) / entryH);
        return idx >= 0 && idx < suggestions.size() ? idx : -1;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────

    @Override
    public void method_25419() {
        activeInstance = null;
        if (parent != null) {
            field_22787.method_1507(parent);
        } else {
            super.method_25419();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private int visibleLogLines() {
        int panelH = Math.min(field_22790 - 40, 420);
        int logH = panelH - 42 - 46;
        return Math.max(1, (logH - 8) / 12);
    }

    private record LogEntry(String text, int color) {}
}
