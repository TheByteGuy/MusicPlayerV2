package com.musicplayer.client;

import com.musicplayer.MusicPlayerMod;
import com.musicplayer.audio.DependencyManager;
import com.musicplayer.audio.YouTubeDownloader;
import com.musicplayer.network.MusicPayloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class ClientPlaybackManager {
    private final YouTubeDownloader downloader;
    private final DependencyManager dependencyManager;
    private final ExecutorService audioExecutor;
    private final Object clipLock = new Object();
    private final AtomicInteger playbackGeneration = new AtomicInteger();

    private CompletableFuture<Void> dependencySetup;
    private Clip currentClip;
    private long pausedMicroseconds;
    private boolean paused;
    private int volumePercent = 100;

    public ClientPlaybackManager(YouTubeDownloader downloader, DependencyManager dependencyManager) {
        this.downloader = downloader;
        this.dependencyManager = dependencyManager;
        this.audioExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r, "musicplayer-audio");
            thread.setDaemon(true);
            return thread;
        });
    }

    public void playTrack(MusicPayloads.PlayTrackPayload payload) {
        int generation = playbackGeneration.incrementAndGet();
        closeCurrentClip();
        volumePercent = payload.volumePercent();

        ensureDependencies().whenComplete((unused, error) -> {
            if (generation != playbackGeneration.get()) {
                return;
            }

            if (error != null || !dependencyManager.isReady()) {
                String message = dependencyManager.getStatus();
                sendError(payload.videoId(), payload.serverMode(), "Dependencies not ready: " + message);
                return;
            }

            downloader.download(payload.url()).thenAccept(result -> {
                if (generation != playbackGeneration.get()) {
                    return;
                }

                if (!result.success()) {
                    sendError(payload.videoId(), payload.serverMode(), result.error());
                    return;
                }

                audioExecutor.execute(() -> openAndPlayClip(generation, payload, result.wavPath()));
            });
        });
    }

    public void stopTrack() {
        playbackGeneration.incrementAndGet();
        closeCurrentClip();
    }

    public void setPaused(boolean shouldPause) {
        Clip clip;
        long resumePosition;

        synchronized (clipLock) {
            clip = currentClip;

            if (clip == null) {
                paused = shouldPause;
                return;
            }

            if (shouldPause) {
                if (paused) {
                    return;
                }
                paused = true;
                pausedMicroseconds = clip.getMicrosecondPosition();
                resumePosition = pausedMicroseconds;
            } else {
                if (!paused) {
                    return;
                }
                paused = false;
                resumePosition = pausedMicroseconds;
            }
        }

        if (shouldPause) {
            clip.stop();
        } else {
            clip.setMicrosecondPosition(resumePosition);
            applyVolume(clip, volumePercent);
            clip.start();
        }
    }

    public void setVolume(int percent) {
        volumePercent = Math.max(0, Math.min(100, percent));

        synchronized (clipLock) {
            if (currentClip != null) {
                applyVolume(currentClip, volumePercent);
            }
        }
    }

    private CompletableFuture<Void> ensureDependencies() {
        synchronized (this) {
            if (dependencySetup == null) {
                dependencySetup = dependencyManager.ensureDependencies();
            }
            return dependencySetup;
        }
    }

    private void openAndPlayClip(int generation, MusicPayloads.PlayTrackPayload payload, Path wavPath) {
        try (AudioInputStream stream = AudioSystem.getAudioInputStream(wavPath.toFile())) {
            Clip clip = AudioSystem.getClip();
            clip.addLineListener(event -> {
                if (event.getType() == LineEvent.Type.STOP) {
                    handleClipStop(clip, payload.videoId(), payload.serverMode());
                }
            });
            clip.open(stream);
            applyVolume(clip, volumePercent);

            long startMicroseconds = Math.max(0L, payload.startTick()) * 50_000L;
            startMicroseconds = Math.min(startMicroseconds, Math.max(clip.getMicrosecondLength() - 1_000L, 0L));
            clip.setMicrosecondPosition(startMicroseconds);

            synchronized (clipLock) {
                if (generation != playbackGeneration.get()) {
                    clip.close();
                    return;
                }

                currentClip = clip;
                pausedMicroseconds = startMicroseconds;
                paused = payload.paused();
            }

            int durationSeconds = Math.max(1, (int) Math.ceil(clip.getMicrosecondLength() / 1_000_000.0));
            sendPayload(new MusicPayloads.PlaybackStartedPayload(payload.videoId(), durationSeconds, payload.serverMode()));

            if (!payload.paused()) {
                clip.start();
            }
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.error("Failed to play downloaded audio", e);
            sendError(payload.videoId(), payload.serverMode(), "Audio playback failed: " + e.getMessage());
        }
    }

    private void handleClipStop(Clip clip, String videoId, boolean serverMode) {
        boolean notifyFinished;

        synchronized (clipLock) {
            if (clip != currentClip) {
                return;
            }

            if (paused) {
                return;
            }

            notifyFinished = clip.getMicrosecondPosition() >= Math.max(clip.getMicrosecondLength() - 1_000L, 0L);
            currentClip = null;
            pausedMicroseconds = 0L;
        }

        clip.close();

        if (notifyFinished) {
            sendPayload(new MusicPayloads.PlaybackFinishedPayload(videoId, serverMode));
        }
    }

    private void closeCurrentClip() {
        Clip clip;

        synchronized (clipLock) {
            clip = currentClip;
            currentClip = null;
            paused = false;
            pausedMicroseconds = 0L;
        }

        if (clip != null) {
            try {
                clip.stop();
            } catch (Exception ignored) {}

            try {
                clip.close();
            } catch (Exception ignored) {}
        }
    }

    private void applyVolume(Clip clip, int percent) {
        if (!clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            return;
        }

        FloatControl control = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);

        if (percent <= 0) {
            control.setValue(control.getMinimum());
            return;
        }

        float gain = (float) (20.0 * Math.log10(percent / 100.0));
        gain = Math.max(control.getMinimum(), Math.min(control.getMaximum(), gain));
        control.setValue(gain);
    }

    private void sendError(String videoId, boolean serverMode, String message) {
        sendPayload(new MusicPayloads.PlaybackErrorPayload(
                videoId,
                message != null ? message : "Unknown playback error",
                serverMode
        ));
    }

    private void sendPayload(class_8710 payload) {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (client.method_1562() == null) {
                return;
            }

            if (ClientPlayNetworking.canSend(payload.method_56479())) {
                ClientPlayNetworking.send(payload);
            }
        });
    }
}
