package com.musicplayer.audio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class NoteSequence {

    private final String title;
    private final TreeMap<Integer, List<NoteEvent>> events; // tick -> list of events
    private int totalTicks;

    public NoteSequence(String title) {
        this.title = title;
        this.events = new TreeMap<>();
        this.totalTicks = 0;
    }

    public void addEvent(int tick, int pitchIndex, float volume) {
        events.computeIfAbsent(tick, k -> new ArrayList<>()).add(new NoteEvent(pitchIndex, volume));
        if (tick >= totalTicks) {
            totalTicks = tick + 1;
        }
    }

    public List<NoteEvent> getEventsAtTick(int tick) {
        List<NoteEvent> list = events.get(tick);
        return list != null ? list : Collections.emptyList();
    }

    public String getTitle() {
        return title;
    }

    public int getTotalTicks() {
        return totalTicks;
    }

    public boolean isEmpty() {
        return events.isEmpty();
    }

    public record NoteEvent(int pitchIndex, float volume) {}
}
