package com.musicplayer.audio;

import com.musicplayer.MusicPlayerMod;
import com.musicplayer.playback.TrackInfo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class YouTubeDownloader {

    private static final Pattern YOUTUBE_ID_PATTERN = Pattern.compile(
            "(?:youtu\\.be/|youtube\\.com/(?:watch\\?v=|embed/|v/|shorts/))([a-zA-Z0-9_-]{11})"
    );
    private static final int MAX_DURATION_SECONDS = 600;
    private static final String SEARCH_DELIMITER = "\u001F";

    private final Path cacheDir;
    private final DependencyManager dependencyManager;
    private final ExecutorService executor;

    public YouTubeDownloader(Path cacheDir, DependencyManager dependencyManager) {
        this.cacheDir = cacheDir;
        this.dependencyManager = dependencyManager;
        this.executor = Executors.newFixedThreadPool(2);
        try {
            Files.createDirectories(cacheDir);
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.error("Failed to create cache directory", e);
        }
    }

    public static String extractVideoId(String url) {
        Matcher matcher = YOUTUBE_ID_PATTERN.matcher(url);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    public static boolean isValidYouTubeUrl(String url) {
        return extractVideoId(url) != null;
    }

    public CompletableFuture<MetadataResult> fetchMetadata(String url) {
        return CompletableFuture.supplyAsync(() -> {
            String videoId = extractVideoId(url);
            if (videoId == null) {
                return MetadataResult.failure("Invalid YouTube URL");
            }

            if (dependencyManager == null || !dependencyManager.isReady()) {
                String status = dependencyManager != null ? dependencyManager.getStatus() : "Dependency manager unavailable";
                return MetadataResult.failure("Dependencies not ready: " + status);
            }

            try {
                CommandResult result = runCommand(List.of(
                        dependencyManager.getYtDlpCommand(),
                        "--no-playlist",
                        "--get-title",
                        "--get-duration",
                        url
                ));

                if (result.exitCode() != 0) {
                    return MetadataResult.failure(extractError(result.output(), result.exitCode(), "Metadata lookup failed"));
                }

                List<String> lines = result.output().lines()
                        .map(String::trim)
                        .filter(line -> !line.isEmpty())
                        .filter(line -> !line.startsWith("WARNING:"))
                        .toList();

                if (lines.isEmpty()) {
                    return MetadataResult.failure("yt-dlp returned no track metadata");
                }

                String title = lines.get(0);
                int durationSeconds = lines.size() > 1 ? parseDurationSeconds(lines.get(1)) : 0;
                return MetadataResult.success(new TrackInfo(videoId, url, title, durationSeconds));
            } catch (Exception e) {
                MusicPlayerMod.LOGGER.error("Failed to fetch track metadata", e);
                return MetadataResult.failure("Metadata error: " + e.getMessage());
            }
        }, executor);
    }

    public CompletableFuture<SearchResult> search(String query, int maxResults) {
        return CompletableFuture.supplyAsync(() -> {
            if (query == null || query.isBlank()) {
                return SearchResult.failure("Search query cannot be empty");
            }

            if (dependencyManager == null || !dependencyManager.isReady()) {
                String status = dependencyManager != null ? dependencyManager.getStatus() : "Dependency manager unavailable";
                return SearchResult.failure("Dependencies not ready: " + status);
            }

            try {
                CommandResult result = runCommand(List.of(
                        dependencyManager.getYtDlpCommand(),
                        "--flat-playlist",
                        "--print",
                        "%(id)s" + SEARCH_DELIMITER + "%(title)s" + SEARCH_DELIMITER + "%(duration,0)s",
                        "ytsearch" + Math.max(1, maxResults) + ":" + query
                ));

                if (result.exitCode() != 0) {
                    return SearchResult.failure(extractError(result.output(), result.exitCode(), "Search failed"));
                }

                List<TrackInfo> tracks = new ArrayList<>();
                for (String line : result.output().lines().map(String::trim).filter(s -> !s.isEmpty()).toList()) {
                    if (line.startsWith("WARNING:")) {
                        continue;
                    }

                    String[] parts = line.split(Pattern.quote(SEARCH_DELIMITER), 3);
                    if (parts.length < 2) {
                        continue;
                    }

                    String videoId = parts[0].trim();
                    if (videoId.length() != 11) {
                        continue;
                    }

                    String title = parts[1].trim();
                    int durationSeconds = parts.length >= 3 ? parseDurationValue(parts[2]) : 0;

                    if (durationSeconds > MAX_DURATION_SECONDS) {
                        continue;
                    }

                    tracks.add(new TrackInfo(
                            videoId,
                            "https://www.youtube.com/watch?v=" + videoId,
                            title,
                            durationSeconds
                    ));
                }

                if (tracks.isEmpty()) {
                    return SearchResult.failure("No playable YouTube results found");
                }

                return SearchResult.success(tracks);
            } catch (Exception e) {
                MusicPlayerMod.LOGGER.error("Failed to search YouTube", e);
                return SearchResult.failure("Search error: " + e.getMessage());
            }
        }, executor);
    }

    public CompletableFuture<DownloadResult> download(String url) {
        return CompletableFuture.supplyAsync(() -> {
            String videoId = extractVideoId(url);
            if (videoId == null) {
                return DownloadResult.failure("Invalid YouTube URL");
            }

            Path wavFile = cacheDir.resolve(videoId + ".wav");

            // Check cache
            if (Files.exists(wavFile)) {
                String title = getCachedTitle(videoId);
                return DownloadResult.success(wavFile, title != null ? title : videoId);
            }

            if (dependencyManager == null || !dependencyManager.isReady()) {
                String status = dependencyManager != null ? dependencyManager.getStatus() : "Dependency manager unavailable";
                return DownloadResult.failure("Dependencies not ready: " + status);
            }

            String ytDlp = dependencyManager.getYtDlpCommand();
            Path ffmpegDirectory = dependencyManager.getFfmpegDirectory();

            try {
                // First, get the title
                String title = fetchTitle(url, ytDlp);

                // Download and convert to WAV using yt-dlp
                ProcessBuilder pb = new ProcessBuilder(
                        ytDlp,
                        "--no-playlist",
                        "--max-filesize", "50m",
                        "--match-filter", "duration<" + MAX_DURATION_SECONDS,
                        "-x",
                        "--audio-format", "wav",
                        "--ffmpeg-location", ffmpegDirectory != null ? ffmpegDirectory.toString() : "",
                        "--postprocessor-args", "-ac 1 -ar 44100 -sample_fmt s16",
                        "-o", cacheDir.resolve(videoId + ".%(ext)s").toString(),
                        url
                );

                // Remove empty --ffmpeg-location if ffmpeg is on PATH
                List<String> cmd = new ArrayList<>(pb.command());
                int ffIdx = cmd.indexOf("--ffmpeg-location");
                if (ffIdx >= 0 && ffIdx + 1 < cmd.size() && cmd.get(ffIdx + 1).isEmpty()) {
                    cmd.remove(ffIdx + 1);
                    cmd.remove(ffIdx);
                }
                pb.command(cmd);
                prependDirectoryToPath(pb, ffmpegDirectory);

                pb.redirectErrorStream(true);
                Process process = pb.start();
                StringBuilder output = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        output.append(line).append("\n");
                        MusicPlayerMod.LOGGER.debug("yt-dlp: {}", line);
                    }
                }

                int exitCode = process.waitFor();
                if (exitCode != 0) {
                    String outStr = output.toString();
                    MusicPlayerMod.LOGGER.error("yt-dlp failed (exit {}): {}", exitCode, outStr);
                    return DownloadResult.failure(extractError(outStr, exitCode, "Download failed"));
                }

                if (!Files.exists(wavFile)) {
                    return DownloadResult.failure("WAV file was not created. Check ffmpeg is working.");
                }

                if (title != null) {
                    Files.writeString(cacheDir.resolve(videoId + ".title"), title);
                }

                return DownloadResult.success(wavFile, title != null ? title : videoId);

            } catch (Exception e) {
                MusicPlayerMod.LOGGER.error("Failed to download YouTube audio", e);
                return DownloadResult.failure("Error: " + e.getMessage());
            }
        }, executor);
    }

    private String fetchTitle(String url, String ytDlpCmd) {
        try {
            ProcessBuilder pb = new ProcessBuilder(ytDlpCmd, "--get-title", "--no-playlist", url);
            pb.redirectErrorStream(true);
            Process process = pb.start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String title = reader.readLine();
                process.waitFor();
                return title;
            }
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("Failed to fetch title", e);
            return null;
        }
    }

    private String getCachedTitle(String videoId) {
        try {
            Path titleFile = cacheDir.resolve(videoId + ".title");
            if (Files.exists(titleFile)) {
                return Files.readString(titleFile).trim();
            }
        } catch (Exception ignored) {}
        return null;
    }

    public void shutdown() {
        executor.shutdownNow();
    }

    private void prependDirectoryToPath(ProcessBuilder pb, Path directory) {
        if (directory == null) {
            return;
        }

        String location = directory.toAbsolutePath().normalize().toString();
        var environment = pb.environment();
        String pathKey = environment.containsKey("PATH")
                ? "PATH"
                : environment.containsKey("Path") ? "Path" : "PATH";
        String existingPath = environment.get(pathKey);
        if (existingPath == null || existingPath.isBlank()) {
            environment.put(pathKey, location);
            return;
        }

        environment.put(pathKey, location + java.io.File.pathSeparator + existingPath);
    }

    private CommandResult runCommand(List<String> command) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        Process process = pb.start();
        StringBuilder output = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
                MusicPlayerMod.LOGGER.debug("command output: {}", line);
            }
        }

        int exitCode = process.waitFor();
        return new CommandResult(exitCode, output.toString());
    }

    private String extractError(String output, int exitCode, String fallbackPrefix) {
        if (output != null && output.contains("ERROR:")) {
            int errIdx = output.lastIndexOf("ERROR:");
            return output.substring(errIdx).trim();
        }
        return fallbackPrefix + " (exit code " + exitCode + ")";
    }

    private int parseDurationSeconds(String durationText) {
        if (durationText == null || durationText.isBlank() || durationText.equalsIgnoreCase("NA")) {
            return 0;
        }

        String[] parts = durationText.trim().split(":");
        int total = 0;

        for (String part : parts) {
            total = (total * 60) + Integer.parseInt(part);
        }

        return Math.max(total, 0);
    }

    private int parseDurationValue(String rawDuration) {
        if (rawDuration == null || rawDuration.isBlank()) {
            return 0;
        }

        try {
            return Math.max(0, (int) Math.round(Double.parseDouble(rawDuration.trim())));
        } catch (NumberFormatException ignored) {
            return parseDurationSeconds(rawDuration);
        }
    }

    private record CommandResult(int exitCode, String output) {}

    public record DownloadResult(boolean success, Path wavPath, String title, String error) {
        public static DownloadResult success(Path wavPath, String title) {
            return new DownloadResult(true, wavPath, title, null);
        }

        public static DownloadResult failure(String error) {
            return new DownloadResult(false, null, null, error);
        }
    }

    public record MetadataResult(boolean success, TrackInfo track, String error) {
        public static MetadataResult success(TrackInfo track) {
            return new MetadataResult(true, track, null);
        }

        public static MetadataResult failure(String error) {
            return new MetadataResult(false, null, error);
        }
    }

    public record SearchResult(boolean success, List<TrackInfo> tracks, String error) {
        public static SearchResult success(List<TrackInfo> tracks) {
            return new SearchResult(true, List.copyOf(tracks), null);
        }

        public static SearchResult failure(String error) {
            return new SearchResult(false, List.of(), error);
        }
    }
}
