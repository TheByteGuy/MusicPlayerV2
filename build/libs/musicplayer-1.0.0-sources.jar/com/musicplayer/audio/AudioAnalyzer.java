package com.musicplayer.audio;

import com.musicplayer.MusicPlayerMod;
import com.musicplayer.util.NoteUtils;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AudioAnalyzer {

    private static final int FFT_SIZE = 2048;
    private static final int HOP_SIZE = 2205; // ~50ms at 44100Hz = ~1 game tick per frame, use 2 ticks
    private static final int MAX_POLYPHONY = 3; // max simultaneous notes
    private static final double MIN_MAGNITUDE_THRESHOLD = 50.0;
    private static final int TICKS_PER_FRAME = 2; // each analysis frame = 2 game ticks (100ms)

    /**
     * Analyze a WAV file and produce a NoteSequence.
     */
    public static NoteSequence analyze(Path wavFile, String title) {
        NoteSequence sequence = new NoteSequence(title);

        try (AudioInputStream ais = AudioSystem.getAudioInputStream(wavFile.toFile())) {
            AudioFormat format = ais.getFormat();
            float sampleRate = format.getSampleRate();
            int channels = format.getChannels();
            int sampleSizeBytes = format.getSampleSizeInBits() / 8;
            int frameSize = channels * sampleSizeBytes;

            // Read all audio data
            byte[] audioBytes = ais.readAllBytes();
            int totalSamples = audioBytes.length / frameSize;

            // Convert to mono double array
            double[] samples = new double[totalSamples];
            ByteBuffer buffer = ByteBuffer.wrap(audioBytes).order(ByteOrder.LITTLE_ENDIAN);

            for (int i = 0; i < totalSamples; i++) {
                if (sampleSizeBytes == 2) {
                    short sample = buffer.getShort(i * frameSize);
                    samples[i] = sample / 32768.0;
                } else if (sampleSizeBytes == 1) {
                    byte sample = audioBytes[i * frameSize];
                    samples[i] = (sample - 128) / 128.0;
                }
            }

            // Process in windows
            int tick = 0;
            double minFreq = NoteUtils.getMinFrequency();
            double maxFreq = NoteUtils.getMaxFrequency();

            for (int offset = 0; offset + FFT_SIZE <= totalSamples; offset += HOP_SIZE) {
                double[] real = new double[FFT_SIZE];
                double[] imag = new double[FFT_SIZE];

                System.arraycopy(samples, offset, real, 0, FFT_SIZE);
                FFT.applyHammingWindow(real);
                FFT.fft(real, imag);

                double[] magnitudes = FFT.magnitude(real, imag);
                double freqResolution = sampleRate / FFT_SIZE;

                // Find frequency range indices for noteblock range
                int minBin = Math.max(1, (int) (minFreq / freqResolution));
                int maxBin = Math.min(magnitudes.length - 1, (int) (maxFreq / freqResolution));

                // Find peaks in the magnitude spectrum
                List<FreqPeak> peaks = findPeaks(magnitudes, freqResolution, minBin, maxBin);

                // Take top N peaks
                peaks.sort(Comparator.comparingDouble(FreqPeak::magnitude).reversed());
                int count = Math.min(MAX_POLYPHONY, peaks.size());

                // Normalize volume relative to the strongest peak
                double maxMag = count > 0 ? peaks.get(0).magnitude() : 1.0;

                for (int i = 0; i < count; i++) {
                    FreqPeak peak = peaks.get(i);
                    int pitchIndex = NoteUtils.frequencyToPitch(peak.frequency());
                    if (pitchIndex >= 0) {
                        float volume = (float) Math.min(1.0, peak.magnitude() / maxMag);
                        if (volume > 0.1f) {
                            sequence.addEvent(tick, pitchIndex, volume);
                        }
                    }
                }

                tick += TICKS_PER_FRAME;
            }

            MusicPlayerMod.LOGGER.info("Analyzed '{}': {} ticks of noteblock music", title, sequence.getTotalTicks());

        } catch (Exception e) {
            MusicPlayerMod.LOGGER.error("Failed to analyze audio file", e);
        }

        return sequence;
    }

    private static List<FreqPeak> findPeaks(double[] magnitudes, double freqResolution, int minBin, int maxBin) {
        List<FreqPeak> peaks = new ArrayList<>();

        for (int i = minBin + 1; i < maxBin - 1; i++) {
            if (magnitudes[i] > MIN_MAGNITUDE_THRESHOLD
                    && magnitudes[i] > magnitudes[i - 1]
                    && magnitudes[i] > magnitudes[i + 1]) {
                double freq = i * freqResolution;
                peaks.add(new FreqPeak(freq, magnitudes[i]));
            }
        }

        return peaks;
    }

    private record FreqPeak(double frequency, double magnitude) {}
}
