package com.musicplayer.audio;

import com.musicplayer.MusicPlayerMod;

import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class DependencyManager {

    private static final String YT_DLP_WINDOWS_URL = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe";
    private static final String YT_DLP_UNIX_URL = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp";
    private static final String FFMPEG_WINDOWS_URL = "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip";
    private static final String FFMPEG_LINUX_X64_URL = "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-linux64-gpl.tar.xz";
    private static final String FFMPEG_LINUX_ARM64_URL = "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-linuxarm64-gpl.tar.xz";
    private static final String OS_NAME = System.getProperty("os.name", "")
            .toLowerCase(Locale.ROOT)
            .trim();
    private static final String OS_ARCH = System.getProperty("os.arch", "")
            .toLowerCase(Locale.ROOT)
            .trim();
    private static final boolean WINDOWS = OS_NAME.contains("win");
    private static final boolean LINUX = OS_NAME.contains("linux");

    private final Path binDir;
    private final AtomicReference<String> status = new AtomicReference<>("Checking dependencies...");
    private volatile boolean ready = false;
    private volatile String error = null;

    private Path ytDlpPath;
    private Path ffmpegPath;
    private Path ffprobePath;

    public DependencyManager(Path configDir) {
        this.binDir = configDir.resolve("bin");
        try {
            Files.createDirectories(binDir);
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.error("Failed to create bin directory", e);
        }
    }

    public CompletableFuture<Void> ensureDependencies() {
        return CompletableFuture.runAsync(() -> {
            try {
                ready = false;
                error = null;

                // Check yt-dlp
                ytDlpPath = findExecutable("yt-dlp");
                if (ytDlpPath == null) {
                    status.set("Downloading yt-dlp...");
                    MusicPlayerMod.LOGGER.info("Downloading yt-dlp...");
                    ytDlpPath = downloadFile(
                            WINDOWS ? YT_DLP_WINDOWS_URL : YT_DLP_UNIX_URL,
                            binDir.resolve(executableFileName("yt-dlp")),
                            !WINDOWS
                    );
                    if (ytDlpPath == null) {
                        error = "Failed to download yt-dlp. Place " + executableFileName("yt-dlp") + " in " + binDir;
                        status.set(error);
                        return;
                    }
                    MusicPlayerMod.LOGGER.info("yt-dlp downloaded to {}", ytDlpPath);
                }

                // Check ffmpeg + ffprobe together since yt-dlp needs both
                ToolPaths ffmpegTools = findFfmpegTools();
                if (ffmpegTools == null) {
                    status.set("Downloading ffmpeg and ffprobe (this may take a minute)...");
                    MusicPlayerMod.LOGGER.info("Downloading ffmpeg bundle...");
                    ffmpegTools = downloadAndExtractFfmpeg();
                    if (ffmpegTools == null) {
                        error = "Failed to prepare ffmpeg and ffprobe. Place " + executableFileName("ffmpeg")
                                + " and " + executableFileName("ffprobe") + " in " + binDir;
                        status.set(error);
                        return;
                    }
                    MusicPlayerMod.LOGGER.info("ffmpeg tools extracted to ffmpeg={}, ffprobe={}",
                            ffmpegTools.ffmpeg(), ffmpegTools.ffprobe());
                }
                ffmpegPath = ffmpegTools.ffmpeg();
                ffprobePath = ffmpegTools.ffprobe();

                status.set("Ready");
                ready = true;
                MusicPlayerMod.LOGGER.info("All dependencies ready: yt-dlp={}, ffmpeg={}, ffprobe={}",
                        ytDlpPath, ffmpegPath, ffprobePath);

            } catch (Exception e) {
                error = "Dependency setup failed: " + e.getMessage();
                status.set(error);
                MusicPlayerMod.LOGGER.error("Dependency setup failed", e);
            }
        });
    }

    private Path findExecutable(String name) {
        Path local = findLocalExecutable(name);
        if (local != null) {
            return local;
        }

        // Check if on PATH by trying to run it
        if (canExecute(name)) {
            return Paths.get(name); // It's on PATH, use bare name
        }

        if (!WINDOWS) {
            return null;
        }

        // Check common Windows locations
        return findWindowsCommonExecutable(name);
    }

    private Path downloadFile(String url, Path target, boolean makeExecutable) {
        try {
            HttpClient client = HttpClient.newBuilder()
                    .followRedirects(HttpClient.Redirect.ALWAYS)
                    .build();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .build();
            HttpResponse<Path> response = client.send(request, HttpResponse.BodyHandlers.ofFile(target));
            if (response.statusCode() == 200) {
                if (makeExecutable) {
                    ensureExecutablePermission(target);
                    if (!Files.isExecutable(target)) {
                        MusicPlayerMod.LOGGER.error("Downloaded file is not executable: {}", target);
                        return null;
                    }
                }
                return target;
            }
            MusicPlayerMod.LOGGER.error("Download failed with status {}", response.statusCode());
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.error("Download failed: {}", url, e);
        }
        return null;
    }

    private ToolPaths downloadAndExtractFfmpeg() {
        if (WINDOWS) {
            return downloadAndExtractWindowsFfmpeg();
        }
        if (LINUX) {
            return downloadAndExtractLinuxFfmpeg();
        }
        MusicPlayerMod.LOGGER.error("Automatic ffmpeg download is not supported on OS '{}'", OS_NAME);
        return null;
    }

    private ToolPaths downloadAndExtractWindowsFfmpeg() {
        Path zipFile = binDir.resolve("ffmpeg.zip");
        try {
            // Download
            if (downloadFile(FFMPEG_WINDOWS_URL, zipFile, false) == null) {
                return null;
            }

            // Extract ffmpeg.exe and ffprobe.exe from the zip
            Path ffmpegExe = binDir.resolve("ffmpeg.exe");
            Path ffprobeExe = binDir.resolve("ffprobe.exe");
            try (ZipInputStream zis = new ZipInputStream(Files.newInputStream(zipFile))) {
                ZipEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    String name = entry.getName();
                    if (name.endsWith("/bin/ffmpeg.exe") || name.equals("ffmpeg.exe")) {
                        try (OutputStream out = Files.newOutputStream(ffmpegExe)) {
                            zis.transferTo(out);
                        }
                    } else if (name.endsWith("/bin/ffprobe.exe") || name.equals("ffprobe.exe")) {
                        try (OutputStream out = Files.newOutputStream(ffprobeExe)) {
                            zis.transferTo(out);
                        }
                    }
                }
            }

            // Clean up zip
            Files.deleteIfExists(zipFile);

            if (isNonEmptyFile(ffmpegExe) && isNonEmptyFile(ffprobeExe)) {
                return new ToolPaths(ffmpegExe, ffprobeExe);
            }

        } catch (Exception e) {
            MusicPlayerMod.LOGGER.error("FFmpeg download/extract failed", e);
        }

        try { Files.deleteIfExists(zipFile); } catch (Exception ignored) {}
        return null;
    }

    private ToolPaths downloadAndExtractLinuxFfmpeg() {
        String archiveUrl = getLinuxFfmpegUrl();
        if (archiveUrl == null) {
            MusicPlayerMod.LOGGER.error("Automatic ffmpeg download is not supported on Linux architecture '{}'", OS_ARCH);
            return null;
        }

        Path archiveFile = binDir.resolve("ffmpeg.tar.xz");
        Path extractDir = binDir.resolve("ffmpeg-extract");
        Path ffmpegTarget = binDir.resolve("ffmpeg");
        Path ffprobeTarget = binDir.resolve("ffprobe");

        try {
            if (downloadFile(archiveUrl, archiveFile, false) == null) {
                return null;
            }

            deleteRecursively(extractDir);
            Files.createDirectories(extractDir);

            Process process = new ProcessBuilder(
                    "tar",
                    "-xJf",
                    archiveFile.toString(),
                    "-C",
                    extractDir.toString()
            ).redirectErrorStream(true).start();

            String tarOutput = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
            int exitCode = process.waitFor();
            if (exitCode != 0) {
                MusicPlayerMod.LOGGER.error("Failed to extract FFmpeg archive (exit {}): {}", exitCode, tarOutput);
                return null;
            }

            Path extractedFfmpeg = findFirstFileByName(extractDir, "ffmpeg");
            Path extractedFfprobe = findFirstFileByName(extractDir, "ffprobe");
            if (extractedFfmpeg == null || extractedFfprobe == null) {
                MusicPlayerMod.LOGGER.error("FFmpeg archive did not contain both ffmpeg and ffprobe");
                return null;
            }

            Files.copy(extractedFfmpeg, ffmpegTarget, StandardCopyOption.REPLACE_EXISTING);
            Files.copy(extractedFfprobe, ffprobeTarget, StandardCopyOption.REPLACE_EXISTING);
            ensureExecutablePermission(ffmpegTarget);
            ensureExecutablePermission(ffprobeTarget);

            if (Files.isExecutable(ffmpegTarget) && Files.isExecutable(ffprobeTarget)) {
                return new ToolPaths(ffmpegTarget, ffprobeTarget);
            }

            MusicPlayerMod.LOGGER.error("Extracted ffmpeg tools are not executable: ffmpeg={}, ffprobe={}",
                    ffmpegTarget, ffprobeTarget);
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.error("FFmpeg download/extract failed", e);
        } finally {
            try { Files.deleteIfExists(archiveFile); } catch (Exception ignored) {}
            deleteRecursively(extractDir);
        }

        return null;
    }

    public boolean isReady() {
        return ready;
    }

    public String getStatus() {
        return status.get();
    }

    public String getError() {
        return error;
    }

    public String getYtDlpCommand() {
        return ytDlpPath != null ? ytDlpPath.toString() : "yt-dlp";
    }

    public String getFfmpegCommand() {
        return ffmpegPath != null ? ffmpegPath.toString() : "ffmpeg";
    }

    public Path getFfmpegDirectory() {
        if (ffmpegPath == null || ffprobePath == null) {
            return null;
        }

        Path ffmpegParent = ffmpegPath.toAbsolutePath().normalize().getParent();
        Path ffprobeParent = ffprobePath.toAbsolutePath().normalize().getParent();
        if (ffmpegParent == null || !ffmpegParent.equals(ffprobeParent)) {
            return null;
        }

        return ffmpegParent;
    }

    private ToolPaths findFfmpegTools() {
        ToolPaths localTools = findLocalToolPair("ffmpeg", "ffprobe");
        if (localTools != null) {
            return localTools;
        }

        if (canExecute("ffmpeg") && canExecute("ffprobe")) {
            return new ToolPaths(Paths.get("ffmpeg"), Paths.get("ffprobe"));
        }

        if (!WINDOWS) {
            return null;
        }

        Path installedFfmpeg = findWindowsCommonExecutable("ffmpeg");
        Path installedFfprobe = findWindowsCommonExecutable("ffprobe");
        if (installedFfmpeg != null && installedFfprobe != null) {
            return new ToolPaths(installedFfmpeg, installedFfprobe);
        }

        return null;
    }

    private Path findLocalExecutable(String name) {
        for (String candidateName : localExecutableCandidates(name)) {
            Path candidate = binDir.resolve(candidateName);
            if (!Files.isRegularFile(candidate)) {
                continue;
            }

            ensureExecutablePermission(candidate);
            if (WINDOWS || Files.isExecutable(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private String[] localExecutableCandidates(String name) {
        if (WINDOWS) {
            return new String[] {name + ".exe", name};
        }
        return new String[] {name};
    }

    private String executableFileName(String name) {
        return WINDOWS ? name + ".exe" : name;
    }

    private ToolPaths findLocalToolPair(String firstName, String secondName) {
        Path first = findLocalExecutable(firstName);
        Path second = findLocalExecutable(secondName);
        if (first != null && second != null) {
            return new ToolPaths(first, second);
        }
        return null;
    }

    private boolean canExecute(String name) {
        try {
            Process process = new ProcessBuilder(name, "--version")
                    .redirectErrorStream(true)
                    .start();
            process.getInputStream().readAllBytes();
            return process.waitFor() == 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    private Path findWindowsCommonExecutable(String name) {
        String localAppData = System.getenv("LOCALAPPDATA");
        String programFiles = System.getenv("ProgramFiles");
        String[] commonPaths = {
                localAppData != null ? localAppData + "\\" + name + "\\" + name + ".exe" : null,
                programFiles != null ? programFiles + "\\" + name + "\\" + name + ".exe" : null,
                programFiles != null ? programFiles + "\\ffmpeg\\bin\\" + name + ".exe" : null,
                "C:\\ffmpeg\\bin\\" + name + ".exe",
        };
        for (String path : commonPaths) {
            if (path == null) {
                continue;
            }
            Path candidate = Paths.get(path);
            if (Files.exists(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private String getLinuxFfmpegUrl() {
        if (OS_ARCH.contains("amd64") || OS_ARCH.contains("x86_64")) {
            return FFMPEG_LINUX_X64_URL;
        }
        if (OS_ARCH.contains("aarch64") || OS_ARCH.contains("arm64")) {
            return FFMPEG_LINUX_ARM64_URL;
        }
        return null;
    }

    private Path findFirstFileByName(Path root, String fileName) {
        if (root == null || !Files.exists(root)) {
            return null;
        }
        try (Stream<Path> stream = Files.walk(root)) {
            return stream
                    .filter(Files::isRegularFile)
                    .filter(path -> path.getFileName().toString().equals(fileName))
                    .findFirst()
                    .orElse(null);
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("Failed to scan extracted ffmpeg archive", e);
            return null;
        }
    }

    private boolean isNonEmptyFile(Path path) {
        try {
            return path != null && Files.isRegularFile(path) && Files.size(path) > 0;
        } catch (Exception e) {
            return false;
        }
    }

    private void deleteRecursively(Path path) {
        if (path == null || !Files.exists(path)) {
            return;
        }
        try (Stream<Path> stream = Files.walk(path)) {
            stream.sorted(Comparator.reverseOrder()).forEach(target -> {
                try {
                    Files.deleteIfExists(target);
                } catch (Exception e) {
                    MusicPlayerMod.LOGGER.warn("Failed to delete {}", target, e);
                }
            });
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("Failed to clean up {}", path, e);
        }
    }

    private void ensureExecutablePermission(Path path) {
        if (WINDOWS || path == null) {
            return;
        }
        try {
            if (!path.toFile().setExecutable(true, false) && !Files.isExecutable(path)) {
                MusicPlayerMod.LOGGER.warn("Failed to mark {} as executable", path);
            }
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("Failed to update executable permissions for {}", path, e);
        }
    }

    private record ToolPaths(Path ffmpeg, Path ffprobe) {}
}
