package com.musicplayer.audio;

/**
 * Cooley-Tukey FFT implementation for audio frequency analysis.
 */
public final class FFT {

    private FFT() {}

    /**
     * Compute the FFT of a real-valued signal.
     * Input length must be a power of 2.
     *
     * @param real the real part of the input (modified in place)
     * @param imag the imaginary part (should be zeros, modified in place)
     */
    public static void fft(double[] real, double[] imag) {
        int n = real.length;
        if (n == 0 || (n & (n - 1)) != 0) {
            throw new IllegalArgumentException("Length must be a power of 2, got " + n);
        }

        // Bit-reversal permutation
        int bits = Integer.numberOfTrailingZeros(n);
        for (int i = 0; i < n; i++) {
            int j = Integer.reverse(i) >>> (32 - bits);
            if (i < j) {
                double tempR = real[i];
                double tempI = imag[i];
                real[i] = real[j];
                imag[i] = imag[j];
                real[j] = tempR;
                imag[j] = tempI;
            }
        }

        // Cooley-Tukey iterative FFT
        for (int size = 2; size <= n; size *= 2) {
            int halfSize = size / 2;
            double angle = -2.0 * Math.PI / size;
            double wR = Math.cos(angle);
            double wI = Math.sin(angle);

            for (int i = 0; i < n; i += size) {
                double curR = 1.0;
                double curI = 0.0;
                for (int j = 0; j < halfSize; j++) {
                    int evenIdx = i + j;
                    int oddIdx = i + j + halfSize;
                    double tR = curR * real[oddIdx] - curI * imag[oddIdx];
                    double tI = curR * imag[oddIdx] + curI * real[oddIdx];
                    real[oddIdx] = real[evenIdx] - tR;
                    imag[oddIdx] = imag[evenIdx] - tI;
                    real[evenIdx] += tR;
                    imag[evenIdx] += tI;
                    double newCurR = curR * wR - curI * wI;
                    curI = curR * wI + curI * wR;
                    curR = newCurR;
                }
            }
        }
    }

    /**
     * Compute the magnitude spectrum from FFT output.
     * Only returns the first half (positive frequencies).
     */
    public static double[] magnitude(double[] real, double[] imag) {
        int n = real.length / 2;
        double[] mag = new double[n];
        for (int i = 0; i < n; i++) {
            mag[i] = Math.sqrt(real[i] * real[i] + imag[i] * imag[i]);
        }
        return mag;
    }

    /**
     * Apply a Hamming window to the signal.
     */
    public static void applyHammingWindow(double[] signal) {
        int n = signal.length;
        for (int i = 0; i < n; i++) {
            signal[i] *= 0.54 - 0.46 * Math.cos(2.0 * Math.PI * i / (n - 1));
        }
    }
}
