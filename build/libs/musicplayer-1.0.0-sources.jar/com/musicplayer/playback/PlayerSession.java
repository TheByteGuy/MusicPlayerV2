package com.musicplayer.playback;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public class PlayerSession {
    private static final int TICKS_PER_SECOND = 20;

    private final Deque<TrackInfo> queue = new ArrayDeque<>();
    private TrackInfo currentSong;
    private int currentTick;
    private int currentDurationSeconds;
    private boolean playing;
    private boolean paused;
    private boolean playbackStarted;
    private float volume = 1.0f;
    private boolean waitingForUrl;
    private boolean waitingForSearchQuery;
    private final List<TrackInfo> searchResults = new ArrayList<>();
    private boolean showingSearchResults;
    private String searchQuery = "";
    private String statusMessage = "";
    private String errorMessage = null;
    private long errorTimestamp = 0;

    public void playSong(TrackInfo song) {
        this.currentSong = song;
        this.currentTick = 0;
        this.currentDurationSeconds = song != null ? song.getDurationSeconds() : 0;
        this.playing = true;
        this.paused = false;
        this.playbackStarted = false;
        this.statusMessage = song != null ? "Starting: " + song.getTitle() : "Stopped";
        clearError();
    }

    public void queueSong(TrackInfo song) {
        queue.addLast(song);
        if (!hasCurrentSong()) {
            this.statusMessage = "Song queued";
        }
    }

    public void stop() {
        this.currentSong = null;
        this.currentTick = 0;
        this.currentDurationSeconds = 0;
        this.playing = false;
        this.paused = false;
        this.playbackStarted = false;
        this.statusMessage = "Stopped";
    }

    public boolean skip() {
        if (!queue.isEmpty()) {
            playSong(queue.pollFirst());
            return true;
        }
        stop();
        return false;
    }

    public void togglePause() {
        if (playing) {
            paused = !paused;
            statusMessage = paused ? "Paused" : "Playing: " + (currentSong != null ? currentSong.getTitle() : "");
        }
    }

    public void setVolume(float volume) {
        this.volume = Math.max(0.0f, Math.min(2.0f, volume));
    }

    public float getVolume() {
        return volume;
    }

    public int getVolumePercent() {
        return Math.round(volume * 50.0f);
    }

    public void setVolumePercent(int percent) {
        setVolume(percent / 50.0f);
    }

    public boolean isPlaying() {
        return playing && !paused;
    }

    public boolean isPaused() {
        return paused;
    }

    public boolean hasCurrentSong() {
        return currentSong != null;
    }

    public TrackInfo getCurrentSong() {
        return currentSong;
    }

    public int getCurrentTick() {
        return currentTick;
    }

    public void incrementTick() {
        if (playing && !paused && playbackStarted) {
            currentTick++;
        }
    }

    public boolean isFinished() {
        return currentSong != null
                && playbackStarted
                && currentDurationSeconds > 0
                && currentTick >= currentDurationSeconds * TICKS_PER_SECOND;
    }

    public Deque<TrackInfo> getQueue() {
        return queue;
    }

    public List<TrackInfo> getQueueList() {
        return new ArrayList<>(queue);
    }

    public boolean isWaitingForUrl() {
        return waitingForUrl;
    }

    public void setWaitingForUrl(boolean waiting) {
        this.waitingForUrl = waiting;
        if (waiting) {
            this.waitingForSearchQuery = false;
        }
    }

    public boolean isWaitingForSearchQuery() {
        return waitingForSearchQuery;
    }

    public void setWaitingForSearchQuery(boolean waiting) {
        this.waitingForSearchQuery = waiting;
        if (waiting) {
            this.waitingForUrl = false;
        }
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String message) {
        this.statusMessage = message;
    }

    public String getErrorMessage() {
        // Auto-clear errors after 15 seconds
        if (errorMessage != null && System.currentTimeMillis() - errorTimestamp > 15000) {
            errorMessage = null;
        }
        return errorMessage;
    }

    public void setError(String error) {
        this.errorMessage = error;
        this.errorTimestamp = System.currentTimeMillis();
    }

    public void clearError() {
        this.errorMessage = null;
    }

    public boolean hasPlaybackStarted() {
        return playbackStarted;
    }

    public void markPlaybackStarted(int durationSeconds) {
        if (currentSong == null) {
            return;
        }

        this.playbackStarted = true;
        if (durationSeconds > 0) {
            this.currentDurationSeconds = durationSeconds;
        }
        this.statusMessage = "Playing: " + currentSong.getTitle();
    }

    public float getProgress() {
        if (currentSong == null || currentDurationSeconds <= 0) return 0f;
        return Math.min(1.0f, (float) currentTick / (currentDurationSeconds * TICKS_PER_SECOND));
    }

    public String getProgressTime() {
        if (currentSong == null) return "0:00 / 0:00";
        int currentSeconds = currentTick / TICKS_PER_SECOND;
        int totalSeconds = currentDurationSeconds;
        return formatTime(currentSeconds) + " / " + formatTime(totalSeconds);
    }

    public int getCurrentDurationSeconds() {
        return currentDurationSeconds;
    }

    private String formatTime(int seconds) {
        int min = seconds / 60;
        int sec = seconds % 60;
        return min + ":" + String.format("%02d", sec);
    }

    public void clearQueue() {
        queue.clear();
    }

    public void setSearchResults(String query, List<TrackInfo> results) {
        searchResults.clear();
        searchResults.addAll(results);
        searchQuery = query != null ? query : "";
        showingSearchResults = !searchResults.isEmpty();
    }

    public List<TrackInfo> getSearchResults() {
        return new ArrayList<>(searchResults);
    }

    public boolean hasSearchResults() {
        return !searchResults.isEmpty();
    }

    public boolean isShowingSearchResults() {
        return showingSearchResults && hasSearchResults();
    }

    public void setShowingSearchResults(boolean showingSearchResults) {
        this.showingSearchResults = showingSearchResults && hasSearchResults();
    }

    public void clearSearchResults() {
        searchResults.clear();
        searchQuery = "";
        showingSearchResults = false;
    }

    public String getSearchQuery() {
        return searchQuery;
    }
}
