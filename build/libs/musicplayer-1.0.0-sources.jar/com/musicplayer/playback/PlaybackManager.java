package com.musicplayer.playback;

import com.musicplayer.MusicPlayerMod;
import com.musicplayer.audio.DependencyManager;
import com.musicplayer.audio.YouTubeDownloader;
import com.musicplayer.network.MusicPayloads;
import com.musicplayer.ui.MusicUiState;
import com.musicplayer.util.ModBuildInfo;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class PlaybackManager {
    private static final Scope SERVER_SCOPE = new Scope(PlaybackMode.SERVER, null);
    private static final ModBuildInfo.BuildInfo SERVER_BUILD = ModBuildInfo.current();

    private final Map<UUID, PlayerSession> localSessions = new ConcurrentHashMap<>();
    private final Map<UUID, PlaybackMode> playerModes = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> playerVolumes = new ConcurrentHashMap<>();
    private final java.util.Set<UUID> connectedClients = ConcurrentHashMap.newKeySet();
    private final java.util.Set<UUID> readyClients = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Boolean> compatibleClients = new ConcurrentHashMap<>();
    private final Map<UUID, String> clientBuildStatus = new ConcurrentHashMap<>();
    private final PlayerSession serverSession = new PlayerSession();
    private final YouTubeDownloader downloader;
    private final Map<String, TrackInfo> trackCache = new ConcurrentHashMap<>();

    public PlaybackManager(DependencyManager dependencyManager) {
        Path cacheDir = Paths.get("config", "musicplayer", "server", "cache");
        this.downloader = new YouTubeDownloader(cacheDir, dependencyManager);
    }

    public PlayerSession getOrCreateSession(UUID playerId) {
        return getLocalSession(playerId);
    }

    public PlayerSession getSession(class_3222 player) {
        return getSession(scopeFor(player));
    }

    public PlaybackMode getPlayerMode(class_3222 player) {
        return playerModes.getOrDefault(player.method_5667(), PlaybackMode.LOCAL);
    }

    public int getPlayerVolumePercent(UUID playerId) {
        return clampVolume(playerVolumes.getOrDefault(playerId, 100));
    }

    public void setPlayerMode(class_3222 player, PlaybackMode mode) {
        PlaybackMode previousMode = getPlayerMode(player);
        if (previousMode == mode) {
            sendUiState(player);
            return;
        }

        playerModes.put(player.method_5667(), mode);
        syncPlayerToActiveMode(player);
        sendUiState(player);
        player.method_7353(
                class_2561.method_43470("[Music] ").method_27692(class_124.field_1065)
                        .method_10852(class_2561.method_43470("Switched to " + mode.displayName().toLowerCase() + " mode.").method_27692(class_124.field_1075)),
                false
        );
    }

    public void removePlayer(UUID playerId) {
        PlayerSession session = localSessions.remove(playerId);
        if (session != null) {
            session.stop();
        }
        connectedClients.remove(playerId);
        readyClients.remove(playerId);
        compatibleClients.remove(playerId);
        clientBuildStatus.remove(playerId);
        playerModes.remove(playerId);
        playerVolumes.remove(playerId);
    }

    public void tick(MinecraftServer server) {
        for (Map.Entry<UUID, PlayerSession> entry : localSessions.entrySet()) {
            class_3222 player = server.method_3760().method_14602(entry.getKey());
            if (player == null || getPlayerMode(player) != PlaybackMode.LOCAL || !canControlClient(player)) {
                continue;
            }
            tickSession(server, localScope(entry.getKey()), entry.getValue());
        }

        if (canControlScope(server, SERVER_SCOPE)) {
            tickSession(server, SERVER_SCOPE, serverSession);
        }
    }

    public void openClientGui(class_3222 player) {
        if (!hasClientMod(player)) {
            player.method_7353(
                    class_2561.method_43470("[Music] ").method_27692(class_124.field_1065)
                            .method_10852(class_2561.method_43470("Client mod not detected yet. Reconnect if this keeps happening.").method_27692(class_124.field_1061)),
                    false
            );
            return;
        }
        ServerPlayNetworking.send(player, new MusicPayloads.OpenMusicUiPayload(createUiState(player).toNbt()));
    }

    public void sendUiState(class_3222 player) {
        if (hasClientMod(player)) {
            ServerPlayNetworking.send(player, new MusicPayloads.MusicUiStatePayload(createUiState(player).toNbt()));
        }
    }

    public void handleUiAction(class_3222 player, class_2487 data) {
        if (!isClientCompatible(player)) {
            sendUiState(player);
            return;
        }

        String action = data.method_68564("action", "");
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        MinecraftServer server = player.method_64396().method_9211();

        switch (action) {
            case "set_mode" -> setPlayerMode(player, PlaybackMode.fromString(data.method_68564("mode", PlaybackMode.LOCAL.id())));
            case "search" -> searchTracks(player, data.method_68564("query", "").trim(), false);
            case "url_play" -> playUrl(player, data.method_68564("url", "").trim(), false);
            case "url_queue" -> playUrl(player, data.method_68564("url", "").trim(), true);
            case "toggle_pause" -> togglePause(player);
            case "stop" -> stop(player);
            case "skip" -> skip(player);
            case "restart" -> restart(player);
            case "set_volume" -> setVolume(player, data.method_68083("volumePercent", getPlayerVolumePercent(player.method_5667())));
            case "play_search_result" -> playSearchResult(player, data.method_68083("index", -1), data.method_68566("queueOnly", false));
            case "remove_queue_item" -> removeQueueItem(player, data.method_68083("index", -1));
            case "play_queue_item" -> playQueueItemNow(player, data.method_68083("index", -1));
            case "clear_queue" -> {
                session.clearQueue();
                session.setStatusMessage(scope.mode() == PlaybackMode.SERVER ? "Server queue cleared" : "Queue cleared");
                broadcastUiState(server, scope);
            }
            case "clear_search" -> {
                session.clearSearchResults();
                session.setStatusMessage(scope.mode() == PlaybackMode.SERVER ? "Server search cleared" : "Search results cleared");
                broadcastUiState(server, scope);
            }
            default -> sendUiState(player);
        }
    }

    public void playUrl(class_3222 player, String url, boolean queueOnly) {
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        String videoId = YouTubeDownloader.extractVideoId(url);
        MinecraftServer server = player.method_64396().method_9211();
        UUID playerId = player.method_5667();
        DependencyManager dependencyManager = MusicPlayerMod.getDependencyManager();

        if (videoId == null) {
            session.setError("Invalid YouTube URL");
            session.setStatusMessage("Invalid YouTube URL");
            player.method_7353(class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Invalid YouTube URL!").method_27692(class_124.field_1061)), false);
            broadcastUiState(server, scope);
            return;
        }

        if (!canControlScope(server, scope)) {
            session.setError(scope.mode() == PlaybackMode.SERVER ? "Nobody in server mode is ready for playback" : "Client mod not detected");
            session.setStatusMessage("Playback unavailable");
            player.method_7353(
                    class_2561.method_43470("[Music] ").method_27692(class_124.field_1065)
                            .method_10852(class_2561.method_43470(scope.mode() == PlaybackMode.SERVER ? "No ready clients are listening in server mode." : "Install the mod on your client to play real audio.").method_27692(class_124.field_1061)),
                    false
            );
            broadcastUiState(server, scope);
            return;
        }

        if (dependencyManager == null || !dependencyManager.isReady()) {
            String depStatus = dependencyManager != null ? dependencyManager.getStatus() : "Server is still starting";
            session.setError("Dependencies not ready: " + depStatus);
            session.setStatusMessage("Dependencies not ready");
            player.method_7353(class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Not ready: " + depStatus).method_27692(class_124.field_1061)), false);
            broadcastUiState(server, scope);
            return;
        }

        TrackInfo cached = trackCache.get(videoId);
        if (cached != null) {
            onTrackReady(server, scope, player, cached, queueOnly);
            return;
        }

        session.setStatusMessage("Fetching track info...");
        session.clearError();
        broadcastUiState(server, scope);

        downloader.fetchMetadata(url).thenAccept(result -> server.execute(() -> {
            class_3222 onlinePlayer = server.method_3760().method_14602(playerId);
            if (onlinePlayer == null) {
                return;
            }
            if (!result.success()) {
                session.setError(result.error());
                session.setStatusMessage("Metadata lookup failed");
                onlinePlayer.method_7353(class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Failed: " + result.error()).method_27692(class_124.field_1061)), false);
                broadcastUiState(server, scope);
                return;
            }
            trackCache.put(videoId, result.track());
            onTrackReady(server, scope, onlinePlayer, result.track(), queueOnly);
        }));
    }

    public void searchTracks(class_3222 player, String query) {
        searchTracks(player, query, true);
    }

    public void searchTracks(class_3222 player, String query, boolean reopenOnSuccess) {
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        MinecraftServer server = player.method_64396().method_9211();
        UUID playerId = player.method_5667();
        DependencyManager dependencyManager = MusicPlayerMod.getDependencyManager();

        if (dependencyManager == null || !dependencyManager.isReady()) {
            String depStatus = dependencyManager != null ? dependencyManager.getStatus() : "Server is still starting";
            session.setError("Dependencies not ready: " + depStatus);
            session.setStatusMessage("Dependencies not ready");
            player.method_7353(class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Not ready: " + depStatus).method_27692(class_124.field_1061)), false);
            broadcastUiState(server, scope);
            return;
        }

        if (query == null || query.isBlank()) {
            session.setError("Search query cannot be empty");
            session.setStatusMessage("Enter a search query");
            player.method_7353(class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Type a search query, not an empty message.").method_27692(class_124.field_1061)), false);
            broadcastUiState(server, scope);
            return;
        }

        session.setWaitingForSearchQuery(false);
        session.setStatusMessage("Searching YouTube...");
        session.clearError();
        broadcastUiState(server, scope);

        downloader.search(query, 21).thenAccept(result -> server.execute(() -> {
            class_3222 onlinePlayer = server.method_3760().method_14602(playerId);
            if (onlinePlayer == null) {
                return;
            }
            if (!result.success()) {
                session.setError(result.error());
                session.setStatusMessage("Search failed");
                onlinePlayer.method_7353(class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Search failed: " + result.error()).method_27692(class_124.field_1061)), false);
                broadcastUiState(server, scope);
                return;
            }
            for (TrackInfo track : result.tracks()) {
                trackCache.put(track.getVideoId(), track);
            }
            session.setSearchResults(query, result.tracks());
            session.setShowingSearchResults(true);
            session.setStatusMessage("Results for: " + query);
            onlinePlayer.method_7353(class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Found " + result.tracks().size() + " videos.").method_27692(class_124.field_1060)), false);
            broadcastUiState(server, scope);
            if (reopenOnSuccess) {
                openClientGui(onlinePlayer);
            }
        }));
    }

    public void playTrack(class_3222 player, TrackInfo track, boolean queueOnly) {
        if (track != null) {
            trackCache.put(track.getVideoId(), track);
            onTrackReady(player.method_64396().method_9211(), scopeFor(player), player, track, queueOnly);
        }
    }

    public void stop(class_3222 player) {
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        session.stop();
        sendStop(player.method_64396().method_9211(), scope);
        broadcastUiState(player.method_64396().method_9211(), scope);
    }

    public void restart(class_3222 player) {
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        TrackInfo currentTrack = session.getCurrentSong();
        if (currentTrack == null) {
            return;
        }
        session.playSong(currentTrack);
        if (!sendPlayTrack(player.method_64396().method_9211(), scope, currentTrack, 0, false, player)) {
            session.stop();
        }
        broadcastUiState(player.method_64396().method_9211(), scope);
    }

    public boolean skip(class_3222 player) {
        return skipScope(player.method_64396().method_9211(), scopeFor(player), player);
    }

    public void togglePause(class_3222 player) {
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        session.togglePause();
        broadcastPause(player.method_64396().method_9211(), scope, session.isPaused());
        broadcastUiState(player.method_64396().method_9211(), scope);
    }

    public void setVolume(class_3222 player, int percent) {
        playerVolumes.put(player.method_5667(), clampVolume(percent));
        if (getSession(player).hasCurrentSong() && canControlClient(player)) {
            ServerPlayNetworking.send(player, new MusicPayloads.SetVolumePayload(getPlayerVolumePercent(player.method_5667())));
        }
        sendUiState(player);
    }

    public void handlePlaybackStarted(class_3222 player, String videoId, int durationSeconds, boolean serverMode) {
        Scope scope = serverMode ? SERVER_SCOPE : localScope(player.method_5667());
        PlayerSession session = getSession(scope);
        if (matchesCurrentTrack(session, videoId)) {
            session.markPlaybackStarted(durationSeconds);
            broadcastUiState(player.method_64396().method_9211(), scope);
        }
    }

    public void handleClientReady(class_3222 player) {
        UUID playerId = player.method_5667();
        connectedClients.add(playerId);
        readyClients.remove(playerId);
        compatibleClients.put(playerId, false);
        clientBuildStatus.put(playerId, "Waiting for build verification from client...");
        sendUiState(player);
    }

    public void handleClientBuildInfo(class_3222 player, String clientVersion, String clientHash) {
        UUID playerId = player.method_5667();
        connectedClients.add(playerId);

        boolean isOwner = "4SU".equals(player.method_5477().getString());
        boolean hashMatch = !clientHash.isBlank()
                && SERVER_BUILD.hasHash()
                && SERVER_BUILD.hash().equalsIgnoreCase(clientHash);
        boolean compatible = isOwner || hashMatch;

        compatibleClients.put(playerId, compatible);
        if (compatible) {
            readyClients.add(playerId);
            clientBuildStatus.put(playerId, "");
            syncPlayerToActiveMode(player);
            if (isOwner && !hashMatch) {
                String status = buildMismatchStatus(clientVersion, clientHash);
                clientBuildStatus.put(playerId, status);
                player.method_7353(
                        class_2561.method_43470("[Music] ").method_27692(class_124.field_1065)
                                .method_10852(class_2561.method_43470(status).method_27692(class_124.field_1054)),
                        false
                );
            }
        } else {
            readyClients.remove(playerId);
            String status = buildMismatchStatus(clientVersion, clientHash);
            clientBuildStatus.put(playerId, status);
            player.method_7353(
                    class_2561.method_43470("[Music] ").method_27692(class_124.field_1065)
                            .method_10852(class_2561.method_43470(status).method_27692(class_124.field_1061)),
                    false
            );
        }

        sendUiState(player);
    }

    public void handlePlaybackFinished(class_3222 player, String videoId, boolean serverMode) {
        Scope scope = serverMode ? SERVER_SCOPE : localScope(player.method_5667());
        PlayerSession session = getSession(scope);
        if (matchesCurrentTrack(session, videoId)) {
            finishCurrentTrack(player.method_64396().method_9211(), scope);
        }
    }

    public void handlePlaybackError(class_3222 player, String videoId, String error, boolean serverMode) {
        Scope scope = serverMode ? SERVER_SCOPE : localScope(player.method_5667());
        PlayerSession session = getSession(scope);
        if (!matchesCurrentTrack(session, videoId)) {
            return;
        }
        MinecraftServer server = player.method_64396().method_9211();

        if (serverMode && getReadyAudience(server, scope).size() > 1) {
            player.method_7353(
                    class_2561.method_43470("[Music] ").method_27692(class_124.field_1065)
                            .method_10852(class_2561.method_43470("Your client could not play this track: " + error).method_27692(class_124.field_1061)),
                    false
            );
            return;
        }

        session.setError(error);
        session.setStatusMessage("Playback failed");
        sendScopeMessage(
                server,
                scope,
                class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Playback failed: " + error).method_27692(class_124.field_1061)),
                false
        );
        skipScope(server, scope, player);
    }

    public void shutdown() {
        for (PlayerSession session : localSessions.values()) {
            session.stop();
        }
        localSessions.clear();
        serverSession.stop();
        playerModes.clear();
        playerVolumes.clear();
        connectedClients.clear();
        readyClients.clear();
        compatibleClients.clear();
        clientBuildStatus.clear();
        downloader.shutdown();
    }

    private void tickSession(MinecraftServer server, Scope scope, PlayerSession session) {
        if (!session.isPlaying() || !session.hasPlaybackStarted()) {
            return;
        }
        session.incrementTick();
        if (session.isFinished()) {
            finishCurrentTrack(server, scope);
        }
    }

    private void onTrackReady(MinecraftServer server, Scope scope, class_3222 actor, TrackInfo track, boolean queueOnly) {
        PlayerSession session = getSession(scope);
        if (queueOnly && session.hasCurrentSong()) {
            session.queueSong(track);
            session.setStatusMessage("Queued: " + track.getTitle());
            session.clearError();
            sendScopeMessage(server, scope, class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Queued: " + track.getTitle()).method_27692(class_124.field_1075)), false);
            broadcastUiState(server, scope);
            return;
        }

        session.playSong(track);
        if (!sendPlayTrack(server, scope, track, 0, false, actor)) {
            session.stop();
            broadcastUiState(server, scope);
            return;
        }
        sendScopeMessage(server, scope, class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Now playing: " + track.getTitle()).method_27692(class_124.field_1060)), false);
        broadcastUiState(server, scope);
    }

    private void finishCurrentTrack(MinecraftServer server, Scope scope) {
        PlayerSession session = getSession(scope);
        if (!session.skip()) {
            session.stop();
            sendStop(server, scope);
            sendScopeMessage(server, scope, class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Finished playing.").method_27692(class_124.field_1080)), true);
            broadcastUiState(server, scope);
            return;
        }

        TrackInfo nextTrack = session.getCurrentSong();
        if (nextTrack == null || !sendPlayTrack(server, scope, nextTrack, 0, false, null)) {
            session.stop();
            sendStop(server, scope);
            broadcastUiState(server, scope);
            return;
        }
        sendScopeMessage(server, scope, class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Now: " + nextTrack.getTitle()).method_27692(class_124.field_1060)), true);
        broadcastUiState(server, scope);
    }

    private void playSearchResult(class_3222 player, int index, boolean queueOnly) {
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        List<TrackInfo> results = session.getSearchResults();
        if (index < 0 || index >= results.size()) {
            session.setError("That search result is no longer available");
            broadcastUiState(player.method_64396().method_9211(), scope);
            return;
        }
        playTrack(player, results.get(index), queueOnly);
    }

    private void removeQueueItem(class_3222 player, int index) {
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        List<TrackInfo> queueList = session.getQueueList();
        if (index < 0 || index >= queueList.size()) {
            session.setError("That queue entry no longer exists");
            broadcastUiState(player.method_64396().method_9211(), scope);
            return;
        }
        TrackInfo removed = queueList.get(index);
        queueList.remove(index);
        rebuildQueue(session, queueList);
        session.setStatusMessage("Removed: " + removed.getTitle());
        sendScopeMessage(player.method_64396().method_9211(), scope, class_2561.method_43470("Removed: " + removed.getTitle()).method_27692(class_124.field_1080), false);
        broadcastUiState(player.method_64396().method_9211(), scope);
    }

    private void playQueueItemNow(class_3222 player, int index) {
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        List<TrackInfo> queueList = session.getQueueList();
        if (index < 0 || index >= queueList.size()) {
            session.setError("That queue entry no longer exists");
            broadcastUiState(player.method_64396().method_9211(), scope);
            return;
        }
        TrackInfo selected = queueList.remove(index);
        TrackInfo previousCurrent = session.getCurrentSong();
        rebuildQueue(session, queueList);
        if (previousCurrent != null) {
            session.getQueue().addFirst(previousCurrent);
        }

        session.playSong(selected);
        if (!sendPlayTrack(player.method_64396().method_9211(), scope, selected, 0, false, player)) {
            session.stop();
            broadcastUiState(player.method_64396().method_9211(), scope);
            return;
        }
        sendScopeMessage(player.method_64396().method_9211(), scope, class_2561.method_43470("[Music] ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("Now playing: " + selected.getTitle()).method_27692(class_124.field_1060)), false);
        broadcastUiState(player.method_64396().method_9211(), scope);
    }

    private boolean skipScope(MinecraftServer server, Scope scope, class_3222 feedbackPlayer) {
        PlayerSession session = getSession(scope);
        boolean skipped = session.skip();
        if (skipped) {
            TrackInfo nextTrack = session.getCurrentSong();
            if (nextTrack != null && !sendPlayTrack(server, scope, nextTrack, 0, false, feedbackPlayer)) {
                session.stop();
                sendStop(server, scope);
                broadcastUiState(server, scope);
                return false;
            }
        } else {
            sendStop(server, scope);
        }
        broadcastUiState(server, scope);
        return skipped;
    }

    private void syncPlayerToActiveMode(class_3222 player) {
        if (!canControlClient(player)) {
            return;
        }
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        if (!session.hasCurrentSong()) {
            ServerPlayNetworking.send(player, MusicPayloads.StopTrackPayload.INSTANCE);
            return;
        }

        TrackInfo track = session.getCurrentSong();
        int startTick = session.hasPlaybackStarted() ? session.getCurrentTick() : 0;
        ServerPlayNetworking.send(player, new MusicPayloads.PlayTrackPayload(
                track.getVideoId(),
                track.getUrl(),
                getPlayerVolumePercent(player.method_5667()),
                startTick,
                session.isPaused(),
                scope.mode() == PlaybackMode.SERVER
        ));
    }

    private boolean sendPlayTrack(MinecraftServer server, Scope scope, TrackInfo track, int startTick, boolean paused, class_3222 feedbackPlayer) {
        List<class_3222> recipients = getReadyAudience(server, scope);
        if (recipients.isEmpty()) {
            if (feedbackPlayer != null) {
                feedbackPlayer.method_7353(
                        class_2561.method_43470("[Music] ").method_27692(class_124.field_1065)
                                .method_10852(class_2561.method_43470(scope.mode() == PlaybackMode.SERVER ? "No ready clients are listening in server mode." : "Client mod not detected. Real audio playback is unavailable.").method_27692(class_124.field_1061)),
                        false
                );
            }
            return false;
        }
        for (class_3222 recipient : recipients) {
            ServerPlayNetworking.send(recipient, new MusicPayloads.PlayTrackPayload(
                    track.getVideoId(),
                    track.getUrl(),
                    getPlayerVolumePercent(recipient.method_5667()),
                    Math.max(startTick, 0),
                    paused,
                    scope.mode() == PlaybackMode.SERVER
            ));
        }
        return true;
    }

    private void sendStop(MinecraftServer server, Scope scope) {
        for (class_3222 recipient : getReadyAudience(server, scope)) {
            ServerPlayNetworking.send(recipient, MusicPayloads.StopTrackPayload.INSTANCE);
        }
    }

    private void broadcastPause(MinecraftServer server, Scope scope, boolean paused) {
        for (class_3222 recipient : getReadyAudience(server, scope)) {
            ServerPlayNetworking.send(recipient, new MusicPayloads.PauseTrackPayload(paused));
        }
    }

    private void broadcastUiState(MinecraftServer server, Scope scope) {
        for (class_3222 recipient : getAudience(server, scope)) {
            sendUiState(recipient);
        }
    }

    private void sendScopeMessage(MinecraftServer server, Scope scope, class_2561 message, boolean actionBar) {
        for (class_3222 recipient : getAudience(server, scope)) {
            recipient.method_7353(message, actionBar);
        }
    }

    private List<class_3222> getAudience(MinecraftServer server, Scope scope) {
        List<class_3222> recipients = new ArrayList<>();
        if (scope.mode() == PlaybackMode.SERVER) {
            for (class_3222 player : server.method_3760().method_14571()) {
                if (getPlayerMode(player) == PlaybackMode.SERVER) {
                    recipients.add(player);
                }
            }
            return recipients;
        }
        if (scope.localOwnerId() == null) {
            return recipients;
        }
        class_3222 owner = server.method_3760().method_14602(scope.localOwnerId());
        if (owner != null) {
            recipients.add(owner);
        }
        return recipients;
    }

    private List<class_3222> getReadyAudience(MinecraftServer server, Scope scope) {
        List<class_3222> recipients = new ArrayList<>();
        for (class_3222 player : getAudience(server, scope)) {
            if (canControlClient(player)) {
                recipients.add(player);
            }
        }
        return recipients;
    }

    private boolean hasAudience(MinecraftServer server, Scope scope) {
        return !getAudience(server, scope).isEmpty();
    }

    private boolean canControlScope(MinecraftServer server, Scope scope) {
        return !getReadyAudience(server, scope).isEmpty();
    }

    private boolean matchesCurrentTrack(PlayerSession session, String videoId) {
        TrackInfo currentTrack = session.getCurrentSong();
        return currentTrack != null && currentTrack.getVideoId().equals(videoId);
    }

    private boolean canControlClient(class_3222 player) {
        return readyClients.contains(player.method_5667());
    }

    private boolean hasClientMod(class_3222 player) {
        return connectedClients.contains(player.method_5667());
    }

    private boolean isClientCompatible(class_3222 player) {
        return compatibleClients.getOrDefault(player.method_5667(), false);
    }

    private String getClientBuildStatus(class_3222 player) {
        if (!hasClientMod(player)) {
            return "Waiting for client handshake.";
        }
        return clientBuildStatus.getOrDefault(player.method_5667(), "Waiting for build verification from client...");
    }

    private String buildMismatchStatus(String clientVersion, String clientHash) {
        String serverLabel = SERVER_BUILD.describe();
        String clientLabel = describeClientBuild(clientVersion, clientHash);
        if (clientHash == null || clientHash.isBlank()) {
            return "Build verification missing. Server " + serverLabel + ", client " + clientLabel + ". Update the mod on both sides.";
        }
        return "Build mismatch. Server " + serverLabel + ", client " + clientLabel + ". Update the mod on both sides.";
    }

    private String describeClientBuild(String clientVersion, String clientHash) {
        String version = clientVersion != null && !clientVersion.isBlank() ? clientVersion : "unknown";
        if (clientHash == null || clientHash.isBlank()) {
            return version + " (unknown)";
        }
        return version + " (" + clientHash.substring(0, Math.min(clientHash.length(), 12)) + ")";
    }

    private PlayerSession getLocalSession(UUID playerId) {
        return localSessions.computeIfAbsent(playerId, key -> new PlayerSession());
    }

    private PlayerSession getSession(Scope scope) {
        return scope.mode() == PlaybackMode.SERVER ? serverSession : getLocalSession(scope.localOwnerId());
    }

    private Scope scopeFor(class_3222 player) {
        return getPlayerMode(player) == PlaybackMode.SERVER ? SERVER_SCOPE : localScope(player.method_5667());
    }

    private Scope localScope(UUID playerId) {
        return new Scope(PlaybackMode.LOCAL, playerId);
    }

    private void rebuildQueue(PlayerSession session, List<TrackInfo> tracks) {
        session.getQueue().clear();
        for (TrackInfo track : tracks) {
            session.getQueue().addLast(track);
        }
    }

    private int clampVolume(int percent) {
        return Math.max(0, Math.min(100, percent));
    }

    private MusicUiState createUiState(class_3222 player) {
        Scope scope = scopeFor(player);
        PlayerSession session = getSession(scope);
        DependencyManager dependencyManager = MusicPlayerMod.getDependencyManager();
        String dependencyStatus = dependencyManager != null ? dependencyManager.getStatus() : "Server is starting...";
        String dependencyError = dependencyManager != null && dependencyManager.getError() != null ? dependencyManager.getError() : "";

        return new MusicUiState(
                hasClientMod(player),
                isClientCompatible(player),
                getClientBuildStatus(player),
                dependencyManager != null && dependencyManager.isReady(),
                dependencyStatus,
                dependencyError,
                session.getStatusMessage(),
                session.getErrorMessage(),
                session.getCurrentSong(),
                session.isPlaying(),
                session.isPaused(),
                session.hasPlaybackStarted(),
                session.getCurrentTick(),
                session.getCurrentDurationSeconds(),
                getPlayerVolumePercent(player.method_5667()),
                getPlayerMode(player).id(),
                session.getSearchQuery(),
                session.getSearchResults(),
                session.getQueueList()
        );
    }

    private record Scope(PlaybackMode mode, UUID localOwnerId) {
    }
}
