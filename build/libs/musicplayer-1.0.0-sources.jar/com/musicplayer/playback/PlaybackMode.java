package com.musicplayer.playback;

import java.util.Locale;

public enum PlaybackMode {
    LOCAL("local", "Local"),
    SERVER("server", "Server");

    private final String id;
    private final String displayName;

    PlaybackMode(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public String id() {
        return id;
    }

    public String displayName() {
        return displayName;
    }

    public static PlaybackMode fromString(String value) {
        if (value == null) {
            return LOCAL;
        }

        String normalized = value.trim().toLowerCase(Locale.ROOT);
        for (PlaybackMode mode : values()) {
            if (mode.id.equals(normalized)) {
                return mode;
            }
        }

        return LOCAL;
    }
}
