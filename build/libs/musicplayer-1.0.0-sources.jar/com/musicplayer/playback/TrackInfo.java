package com.musicplayer.playback;

import net.minecraft.class_2487;

public final class TrackInfo {
    private final String videoId;
    private final String url;
    private final String title;
    private final int durationSeconds;

    public TrackInfo(String videoId, String url, String title, int durationSeconds) {
        this.videoId = videoId;
        this.url = url;
        this.title = title != null && !title.isBlank() ? title : videoId;
        this.durationSeconds = Math.max(durationSeconds, 0);
    }

    public String getVideoId() {
        return videoId;
    }

    public String getUrl() {
        return url;
    }

    public String getTitle() {
        return title;
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }

    public int getTotalTicks() {
        return durationSeconds * 20;
    }

    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();
        nbt.method_10582("videoId", videoId);
        nbt.method_10582("url", url);
        nbt.method_10582("title", title);
        nbt.method_10569("durationSeconds", durationSeconds);
        return nbt;
    }

    public static TrackInfo fromNbt(class_2487 nbt) {
        return new TrackInfo(
                nbt.method_68564("videoId", ""),
                nbt.method_68564("url", ""),
                nbt.method_68564("title", ""),
                nbt.method_68083("durationSeconds", 0)
        );
    }
}
