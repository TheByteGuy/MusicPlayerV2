package com.musicplayer.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.musicplayer.MusicPlayerMod;
import com.musicplayer.audio.YouTubeDownloader;
import com.musicplayer.playback.PlaybackMode;
import com.musicplayer.playback.PlayerSession;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import com.musicplayer.playback.PlaybackManager;

public class MusicCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("music")
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    openGui(player);
                    return 1;
                })
                .then(class_2170.method_9247("play")
                        .then(class_2170.method_9244("url", StringArgumentType.greedyString())
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_9207();
                                    String url = StringArgumentType.getString(context, "url");
                                    return playUrl(player, url, false);
                                })))
                .then(class_2170.method_9247("queue")
                        .then(class_2170.method_9244("url", StringArgumentType.greedyString())
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_9207();
                                    String url = StringArgumentType.getString(context, "url");
                                    return playUrl(player, url, true);
                                })))
                .then(class_2170.method_9247("search")
                        .then(class_2170.method_9244("query", StringArgumentType.greedyString())
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_9207();
                                    String query = StringArgumentType.getString(context, "query");
                                    return search(player, query);
                                })))
                .then(class_2170.method_9247("mode")
                        .then(class_2170.method_9247("local")
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_9207();
                                    return setMode(player, PlaybackMode.LOCAL);
                                }))
                        .then(class_2170.method_9247("server")
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_9207();
                                    return setMode(player, PlaybackMode.SERVER);
                                })))
                .then(class_2170.method_9247("stop")
                        .executes(context -> {
                            class_3222 player = context.getSource().method_9207();
                            return stopMusic(player);
                        }))
                .then(class_2170.method_9247("skip")
                        .executes(context -> {
                            class_3222 player = context.getSource().method_9207();
                            return skipMusic(player);
                        }))
                .then(class_2170.method_9247("pause")
                        .executes(context -> {
                            class_3222 player = context.getSource().method_9207();
                            return pauseMusic(player);
                        }))
                .then(class_2170.method_9247("volume")
                        .then(class_2170.method_9244("percent", IntegerArgumentType.integer(0, 100))
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_9207();
                                    int vol = IntegerArgumentType.getInteger(context, "percent");
                                    return setVolume(player, vol);
                                })))
        );
    }

    public static void openGui(class_3222 player) {
        PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
        if (manager == null) {
            player.method_7353(class_2561.method_43470("Music server is still starting.").method_27692(class_124.field_1061), false);
            return;
        }

        manager.openClientGui(player);
    }

    private static int playUrl(class_3222 player, String url, boolean queueOnly) {
        if (!YouTubeDownloader.isValidYouTubeUrl(url)) {
            player.method_7353(
                    class_2561.method_43470("Invalid YouTube URL. Supported formats: youtube.com/watch?v=..., youtu.be/...")
                            .method_27692(class_124.field_1061),
                    false
            );
            return 0;
        }

        PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
        if (manager == null) {
            player.method_7353(class_2561.method_43470("Music server is still starting.").method_27692(class_124.field_1061), false);
            return 0;
        }
        manager.playUrl(player, url, queueOnly);
        return 1;
    }

    private static int search(class_3222 player, String query) {
        PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
        if (manager == null) {
            player.method_7353(class_2561.method_43470("Music server is still starting.").method_27692(class_124.field_1061), false);
            return 0;
        }

        manager.searchTracks(player, query);
        return 1;
    }

    private static int setMode(class_3222 player, PlaybackMode mode) {
        PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
        if (manager == null) {
            player.method_7353(class_2561.method_43470("Music server is still starting.").method_27692(class_124.field_1061), false);
            return 0;
        }

        manager.setPlayerMode(player, mode);
        return 1;
    }

    private static int stopMusic(class_3222 player) {
        PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
        if (manager == null) {
            player.method_7353(class_2561.method_43470("Music server is still starting.").method_27692(class_124.field_1061), false);
            return 0;
        }
        PlayerSession session = manager.getSession(player);
        if (!session.hasCurrentSong()) {
            player.method_7353(class_2561.method_43470("Nothing is playing.").method_27692(class_124.field_1080), false);
            return 0;
        }
        manager.stop(player);
        player.method_7353(class_2561.method_43470("Music stopped.").method_27692(class_124.field_1080), false);
        return 1;
    }

    private static int skipMusic(class_3222 player) {
        PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
        if (manager == null) {
            player.method_7353(class_2561.method_43470("Music server is still starting.").method_27692(class_124.field_1061), false);
            return 0;
        }
        PlayerSession session = manager.getSession(player);
        if (manager.skip(player)) {
            if (session.getCurrentSong() != null) {
                player.method_7353(
                        class_2561.method_43470("Skipped to: " + session.getCurrentSong().getTitle()).method_27692(class_124.field_1060),
                        false
                );
            }
        } else {
            player.method_7353(class_2561.method_43470("Queue is empty.").method_27692(class_124.field_1080), false);
        }
        return 1;
    }

    private static int pauseMusic(class_3222 player) {
        PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
        if (manager == null) {
            player.method_7353(class_2561.method_43470("Music server is still starting.").method_27692(class_124.field_1061), false);
            return 0;
        }
        PlayerSession session = manager.getSession(player);
        if (!session.hasCurrentSong()) {
            player.method_7353(class_2561.method_43470("Nothing is playing.").method_27692(class_124.field_1080), false);
            return 0;
        }
        manager.togglePause(player);
        if (session.isPaused()) {
            player.method_7353(class_2561.method_43470("Music paused.").method_27692(class_124.field_1054), false);
        } else {
            player.method_7353(class_2561.method_43470("Music resumed.").method_27692(class_124.field_1060), false);
        }
        return 1;
    }

    private static int setVolume(class_3222 player, int percent) {
        PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
        if (manager == null) {
            player.method_7353(class_2561.method_43470("Music server is still starting.").method_27692(class_124.field_1061), false);
            return 0;
        }
        manager.setVolume(player, percent);
        player.method_7353(
                class_2561.method_43470("Volume set to " + manager.getPlayerVolumePercent(player.method_5667()) + "%").method_27692(class_124.field_1068),
                false
        );
        return 1;
    }
}
