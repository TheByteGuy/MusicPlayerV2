package com.musicplayer.ui;

import com.musicplayer.playback.PlaybackMode;
import com.musicplayer.playback.TrackInfo;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_3532;

public record MusicUiState(
        boolean clientReady,
        boolean buildCompatible,
        String buildStatus,
        boolean dependencyReady,
        String dependencyStatus,
        String dependencyError,
        String statusMessage,
        String errorMessage,
        TrackInfo currentTrack,
        boolean playing,
        boolean paused,
        boolean playbackStarted,
        int currentTick,
        int durationSeconds,
        int volumePercent,
        String modeId,
        String searchQuery,
        List<TrackInfo> searchResults,
        List<TrackInfo> queue
) {
    public static final MusicUiState EMPTY = new MusicUiState(
            false,
            false,
            "",
            false,
            "",
            "",
            "",
            "",
            null,
            false,
            false,
            false,
            0,
            0,
            100,
            PlaybackMode.LOCAL.id(),
            "",
            List.of(),
            List.of()
    );

    public MusicUiState {
        buildStatus = buildStatus != null ? buildStatus : "";
        dependencyStatus = dependencyStatus != null ? dependencyStatus : "";
        dependencyError = dependencyError != null ? dependencyError : "";
        statusMessage = statusMessage != null ? statusMessage : "";
        errorMessage = errorMessage != null ? errorMessage : "";
        searchQuery = searchQuery != null ? searchQuery : "";
        modeId = modeId != null ? modeId : PlaybackMode.LOCAL.id();
        searchResults = List.copyOf(searchResults);
        queue = List.copyOf(queue);
        volumePercent = class_3532.method_15340(volumePercent, 0, 100);
        currentTick = Math.max(currentTick, 0);
        durationSeconds = Math.max(durationSeconds, 0);
    }

    public boolean hasCurrentTrack() {
        return currentTrack != null;
    }

    public float progress() {
        if (!hasCurrentTrack() || durationSeconds <= 0) {
            return 0.0f;
        }
        return Math.min(1.0f, (float) currentTick / (durationSeconds * 20.0f));
    }

    public String progressText() {
        return formatTime(currentTick / 20) + " / " + formatTime(durationSeconds);
    }

    public boolean isServerMode() {
        return PlaybackMode.SERVER.id().equals(modeId);
    }

    public String modeLabel() {
        return isServerMode() ? PlaybackMode.SERVER.displayName() : PlaybackMode.LOCAL.displayName();
    }

    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();
        nbt.method_10556("clientReady", clientReady);
        nbt.method_10556("buildCompatible", buildCompatible);
        nbt.method_10582("buildStatus", buildStatus);
        nbt.method_10556("dependencyReady", dependencyReady);
        nbt.method_10582("dependencyStatus", dependencyStatus);
        nbt.method_10582("dependencyError", dependencyError);
        nbt.method_10582("statusMessage", statusMessage);
        nbt.method_10582("errorMessage", errorMessage);
        nbt.method_10556("hasCurrentTrack", currentTrack != null);
        if (currentTrack != null) {
            nbt.method_10566("currentTrack", currentTrack.toNbt());
        }
        nbt.method_10556("playing", playing);
        nbt.method_10556("paused", paused);
        nbt.method_10556("playbackStarted", playbackStarted);
        nbt.method_10569("currentTick", currentTick);
        nbt.method_10569("durationSeconds", durationSeconds);
        nbt.method_10569("volumePercent", volumePercent);
        nbt.method_10582("modeId", modeId);
        nbt.method_10582("searchQuery", searchQuery);
        nbt.method_10566("searchResults", writeTracks(searchResults));
        nbt.method_10566("queue", writeTracks(queue));
        return nbt;
    }

    public static MusicUiState fromNbt(class_2487 nbt) {
        TrackInfo currentTrack = nbt.method_68566("hasCurrentTrack", false)
                ? TrackInfo.fromNbt(nbt.method_68568("currentTrack"))
                : null;

        return new MusicUiState(
                nbt.method_68566("clientReady", false),
                nbt.method_68566("buildCompatible", false),
                nbt.method_68564("buildStatus", ""),
                nbt.method_68566("dependencyReady", false),
                nbt.method_68564("dependencyStatus", ""),
                nbt.method_68564("dependencyError", ""),
                nbt.method_68564("statusMessage", ""),
                nbt.method_68564("errorMessage", ""),
                currentTrack,
                nbt.method_68566("playing", false),
                nbt.method_68566("paused", false),
                nbt.method_68566("playbackStarted", false),
                nbt.method_68083("currentTick", 0),
                nbt.method_68083("durationSeconds", 0),
                nbt.method_68083("volumePercent", 100),
                nbt.method_68564("modeId", PlaybackMode.LOCAL.id()),
                nbt.method_68564("searchQuery", ""),
                readTracks(nbt.method_68569("searchResults")),
                readTracks(nbt.method_68569("queue"))
        );
    }

    private static class_2499 writeTracks(List<TrackInfo> tracks) {
        class_2499 list = new class_2499();
        for (TrackInfo track : tracks) {
            list.add(track.toNbt());
        }
        return list;
    }

    private static List<TrackInfo> readTracks(class_2499 list) {
        List<TrackInfo> tracks = new ArrayList<>(list.size());
        for (int i = 0; i < list.size(); i++) {
            tracks.add(TrackInfo.fromNbt(list.method_68582(i)));
        }
        return tracks;
    }

    public static String formatTime(int seconds) {
        int total = Math.max(seconds, 0);
        int minutes = total / 60;
        int remainder = total % 60;
        return minutes + ":" + String.format("%02d", remainder);
    }
}
