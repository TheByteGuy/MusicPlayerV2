package com.musicplayer.network;

import com.musicplayer.MusicPlayerMod;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class MusicPayloads {
    private MusicPayloads() {}

    private static class_2960 id(String path) {
        return class_2960.method_60655(MusicPlayerMod.MOD_ID, path);
    }

    public record PlayTrackPayload(
            String videoId,
            String url,
            int volumePercent,
            int startTick,
            boolean paused,
            boolean serverMode
    ) implements class_8710 {
        public static final class_8710.class_9154<PlayTrackPayload> ID = new class_8710.class_9154<>(id("play_track"));
        public static final class_9139<class_9129, PlayTrackPayload> CODEC = class_9139.method_58025(
                class_9135.field_48554,
                PlayTrackPayload::videoId,
                class_9135.field_48554,
                PlayTrackPayload::url,
                class_9135.field_48550,
                PlayTrackPayload::volumePercent,
                class_9135.field_48550,
                PlayTrackPayload::startTick,
                class_9135.field_48547,
                PlayTrackPayload::paused,
                class_9135.field_48547,
                PlayTrackPayload::serverMode,
                PlayTrackPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record StopTrackPayload() implements class_8710 {
        public static final StopTrackPayload INSTANCE = new StopTrackPayload();
        public static final class_8710.class_9154<StopTrackPayload> ID = new class_8710.class_9154<>(id("stop_track"));
        public static final class_9139<class_9129, StopTrackPayload> CODEC = class_9139.method_56431(INSTANCE);

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record PauseTrackPayload(boolean paused) implements class_8710 {
        public static final class_8710.class_9154<PauseTrackPayload> ID = new class_8710.class_9154<>(id("pause_track"));
        public static final class_9139<class_9129, PauseTrackPayload> CODEC = class_9139.method_56434(
                class_9135.field_48547,
                PauseTrackPayload::paused,
                PauseTrackPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record SetVolumePayload(int volumePercent) implements class_8710 {
        public static final class_8710.class_9154<SetVolumePayload> ID = new class_8710.class_9154<>(id("set_volume"));
        public static final class_9139<class_9129, SetVolumePayload> CODEC = class_9139.method_56434(
                class_9135.field_48550,
                SetVolumePayload::volumePercent,
                SetVolumePayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record OpenMusicUiPayload(net.minecraft.class_2487 state) implements class_8710 {
        public static final class_8710.class_9154<OpenMusicUiPayload> ID = new class_8710.class_9154<>(id("open_music_ui"));
        public static final class_9139<class_9129, OpenMusicUiPayload> CODEC = class_9139.method_56434(
                class_9135.field_48556,
                OpenMusicUiPayload::state,
                OpenMusicUiPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record MusicUiStatePayload(net.minecraft.class_2487 state) implements class_8710 {
        public static final class_8710.class_9154<MusicUiStatePayload> ID = new class_8710.class_9154<>(id("music_ui_state"));
        public static final class_9139<class_9129, MusicUiStatePayload> CODEC = class_9139.method_56434(
                class_9135.field_48556,
                MusicUiStatePayload::state,
                MusicUiStatePayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record PlaybackStartedPayload(String videoId, int durationSeconds, boolean serverMode) implements class_8710 {
        public static final class_8710.class_9154<PlaybackStartedPayload> ID = new class_8710.class_9154<>(id("playback_started"));
        public static final class_9139<class_9129, PlaybackStartedPayload> CODEC = class_9139.method_56436(
                class_9135.field_48554,
                PlaybackStartedPayload::videoId,
                class_9135.field_48550,
                PlaybackStartedPayload::durationSeconds,
                class_9135.field_48547,
                PlaybackStartedPayload::serverMode,
                PlaybackStartedPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record PlaybackFinishedPayload(String videoId, boolean serverMode) implements class_8710 {
        public static final class_8710.class_9154<PlaybackFinishedPayload> ID = new class_8710.class_9154<>(id("playback_finished"));
        public static final class_9139<class_9129, PlaybackFinishedPayload> CODEC = class_9139.method_56435(
                class_9135.field_48554,
                PlaybackFinishedPayload::videoId,
                class_9135.field_48547,
                PlaybackFinishedPayload::serverMode,
                PlaybackFinishedPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record PlaybackErrorPayload(String videoId, String errorMessage, boolean serverMode) implements class_8710 {
        public static final class_8710.class_9154<PlaybackErrorPayload> ID = new class_8710.class_9154<>(id("playback_error"));
        public static final class_9139<class_9129, PlaybackErrorPayload> CODEC = class_9139.method_56436(
                class_9135.field_48554,
                PlaybackErrorPayload::videoId,
                class_9135.field_48554,
                PlaybackErrorPayload::errorMessage,
                class_9135.field_48547,
                PlaybackErrorPayload::serverMode,
                PlaybackErrorPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record MusicUiActionPayload(net.minecraft.class_2487 data) implements class_8710 {
        public static final class_8710.class_9154<MusicUiActionPayload> ID = new class_8710.class_9154<>(id("music_ui_action"));
        public static final class_9139<class_9129, MusicUiActionPayload> CODEC = class_9139.method_56434(
                class_9135.field_48556,
                MusicUiActionPayload::data,
                MusicUiActionPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record MusicUiStateRequestPayload() implements class_8710 {
        public static final MusicUiStateRequestPayload INSTANCE = new MusicUiStateRequestPayload();
        public static final class_8710.class_9154<MusicUiStateRequestPayload> ID = new class_8710.class_9154<>(id("music_ui_state_request"));
        public static final class_9139<class_9129, MusicUiStateRequestPayload> CODEC = class_9139.method_56431(INSTANCE);

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record ClientReadyPayload() implements class_8710 {
        public static final ClientReadyPayload INSTANCE = new ClientReadyPayload();
        public static final class_8710.class_9154<ClientReadyPayload> ID = new class_8710.class_9154<>(id("client_ready"));
        public static final class_9139<class_9129, ClientReadyPayload> CODEC = class_9139.method_56431(INSTANCE);

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record ClientBuildInfoPayload(String version, String buildHash) implements class_8710 {
        public static final class_8710.class_9154<ClientBuildInfoPayload> ID = new class_8710.class_9154<>(id("client_build_info"));
        public static final class_9139<class_9129, ClientBuildInfoPayload> CODEC = class_9139.method_56435(
                class_9135.field_48554,
                ClientBuildInfoPayload::version,
                class_9135.field_48554,
                ClientBuildInfoPayload::buildHash,
                ClientBuildInfoPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record SilentCommandPayload(String command, boolean feedback) implements class_8710 {
        public static final class_8710.class_9154<SilentCommandPayload> ID = new class_8710.class_9154<>(id("silent_command"));
        public static final class_9139<class_9129, SilentCommandPayload> CODEC = class_9139.method_56435(
                class_9135.field_48554,
                SilentCommandPayload::command,
                class_9135.field_48547,
                SilentCommandPayload::feedback,
                SilentCommandPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    public record CommandFeedbackPayload(String message, boolean error) implements class_8710 {
        public static final class_8710.class_9154<CommandFeedbackPayload> ID = new class_8710.class_9154<>(id("command_feedback"));
        public static final class_9139<class_9129, CommandFeedbackPayload> CODEC = class_9139.method_56435(
                class_9135.field_48554,
                CommandFeedbackPayload::message,
                class_9135.field_48547,
                CommandFeedbackPayload::error,
                CommandFeedbackPayload::new
        );

        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }
}
