package com.musicplayer;

import com.musicplayer.audio.DependencyManager;
import com.musicplayer.command.MusicCommand;
import com.musicplayer.network.MusicNetworking;
import com.musicplayer.playback.PlaybackManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Paths;

public class MusicPlayerMod implements ModInitializer {
    public static final String MOD_ID = "musicplayer";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static PlaybackManager playbackManager;
    private static DependencyManager dependencyManager;

    @Override
    public void onInitialize() {
        LOGGER.info("Music Player mod initializing...");

        MusicNetworking.registerPayloadTypes();
        MusicNetworking.registerServerReceivers();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            MusicCommand.register(dispatcher);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (playbackManager != null) {
                playbackManager.tick(server);
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            if (playbackManager != null) {
                playbackManager.removePlayer(handler.method_32311().method_5667());
            }
        });

        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            dependencyManager = new DependencyManager(Paths.get("config", "musicplayer", "server"));
            dependencyManager.ensureDependencies();
            playbackManager = new PlaybackManager(dependencyManager);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (playbackManager != null) {
                playbackManager.shutdown();
                playbackManager = null;
            }
            dependencyManager = null;
        });

        ChatUrlListener.register();

        LOGGER.info("Music Player mod initialized!");
    }

    public static PlaybackManager getPlaybackManager() {
        return playbackManager;
    }

    public static DependencyManager getDependencyManager() {
        return dependencyManager;
    }
}
